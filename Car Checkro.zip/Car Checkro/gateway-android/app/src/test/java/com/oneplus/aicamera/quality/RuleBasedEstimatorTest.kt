package com.oneplus.aicamera.quality

import com.oneplus.aicamera.models.Frame
import org.junit.Assert.assertEquals
import org.junit.Test
import org.mockito.Mockito

/**
 * Unit test to verify the normalization and weighting mathematics of the RuleBasedEstimator
 * on a standard local JVM without loading native OpenCV binaries.
 */
class RuleBasedEstimatorTest {

    @Test
    fun testQualityEstimation_OptimalMetrics() {
        // Mock Frame wrapper to prevent calling native Mat constructors
        val mockFrame = Mockito.mock(Frame::class.java)
        Mockito.`when`(mockFrame.timestamp).thenReturn(1500000000L)
        Mockito.`when`(mockFrame.frameNumber).thenReturn(42L)

        val config = EstimatorConfig(
            blurWeight = 0.4f,
            motionWeight = 0.2f,
            exposureWeight = 0.2f,
            reflectionWeight = 0.2f,
            blurOptimal = 200.0,
            blurMin = 50.0,
            motionMax = 5.0,
            reflectionMax = 5.0
        )
        val estimator = RuleBasedEstimator(config)

        // Perfect conditions (should score 100% quality index)
        val score = estimator.estimate(
            frame = mockFrame,
            blur = 220.0,       // > 200 -> 100%
            motion = 0.0,       // 0% motion -> 100%
            reflection = 0.0,   // 0% glare -> 100%
            brightness = 128.0, // 128 mean -> 100%
            processingTimeMs = 8L
        )

        assertEquals(100, score.quality)
        assertEquals(42L, score.frameNumber)
        assertEquals(1500000000L, score.timestamp)
        assertEquals(8L, score.processingTime)
    }

    @Test
    fun testQualityEstimation_DegradedMetrics() {
        val mockFrame = Mockito.mock(Frame::class.java)
        Mockito.`when`(mockFrame.timestamp).thenReturn(1500000000L)
        Mockito.`when`(mockFrame.frameNumber).thenReturn(43L)

        val config = EstimatorConfig(
            blurWeight = 0.4f,
            motionWeight = 0.2f,
            exposureWeight = 0.2f,
            reflectionWeight = 0.2f,
            blurOptimal = 200.0,
            blurMin = 50.0,
            motionMax = 5.0,
            reflectionMax = 5.0
        )
        val estimator = RuleBasedEstimator(config)

        // Degraded conditions:
        // blur = 125 (50% normalized)
        // motion = 2.5 (50% normalized)
        // brightness = 78 (50% normalized - dev is 50/100)
        // reflection = 2.5 (50% normalized)
        val score = estimator.estimate(
            frame = mockFrame,
            blur = 125.0,
            motion = 2.5,
            reflection = 2.5,
            brightness = 78.0,
            processingTimeMs = 12L
        )

        // All normalized metrics are 50%. Final score must be 50%
        assertEquals(50, score.quality)
    }
}
