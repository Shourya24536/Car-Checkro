package com.oneplus.aicamera.communication.receiver

import android.util.Log
import com.oneplus.aicamera.models.Frame
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * Placeholder implementation of [VideoSource] for RTSP stream protocol.
 * To be implemented using a native library (e.g., FFmpeg, LibVLC) or Android Media3 RTSP client.
 */
class RTSPSource(private val rtspUrl: String) : VideoSource {

    private val _frameFlow = MutableSharedFlow<Frame>(replay = 0, extraBufferCapacity = 8)
    override val frameFlow: SharedFlow<Frame> = _frameFlow.asSharedFlow()

    private var _isStreaming = false
    override val isStreaming: Boolean get() = _isStreaming

    override suspend fun start() {
        if (_isStreaming) return
        _isStreaming = true
        Log.i(TAG, "Connecting to RTSP Stream: $rtspUrl")
        
        // TODO: Initialize RTSP Decoder (e.g., Media3 / FFmpeg / OpenCV VideoCapture)
        // while (_isStreaming) {
        //     val mat = captureNativeRtspFrame()
        //     _frameFlow.emit(Frame(..., mat))
        // }
    }

    override fun stop() {
        _isStreaming = false
        Log.i(TAG, "RTSP connection terminated.")
    }

    companion object {
        private const val TAG = "RTSPSource"
    }
}
