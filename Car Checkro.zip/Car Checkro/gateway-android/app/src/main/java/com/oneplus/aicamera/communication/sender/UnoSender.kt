package com.oneplus.aicamera.communication.sender

import android.util.Log
import com.google.gson.Gson
import com.oneplus.aicamera.models.FrameScore
import com.oneplus.aicamera.network.FrameMetadataDto
import com.oneplus.aicamera.network.UnoqApiService
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.opencv.core.Mat
import org.opencv.core.MatOfByte
import org.opencv.core.MatOfInt
import org.opencv.imgcodecs.Imgcodecs
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Handles communication sending logic, uploading selected image frames and analysis
 * scores to the Arduino UNO-Q (or target dashboard server) using Retrofit multipart.
 */
class UnoSender {

    private val gson = Gson()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)

    @Volatile
    private var apiService: UnoqApiService? = null
    @Volatile
    private var currentUrl: String = ""

    /**
     * Updates the server address and reinstantiates the Retrofit client if changed.
     */
    fun updateServerAddress(host: String, port: Int) {
        val newUrl = "http://$host:$port/"
        if (newUrl == currentUrl && apiService != null) return

        synchronized(this) {
            if (newUrl == currentUrl && apiService != null) return
            currentUrl = newUrl
            Log.i(TAG, "Rebuilding Retrofit service for target base URL: $currentUrl")

            val okHttpClient = OkHttpClient.Builder()
                .connectTimeout(3, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .build()

            val retrofit = Retrofit.Builder()
                .baseUrl(currentUrl)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()

            apiService = retrofit.create(UnoqApiService::class.java)
        }
    }

    /**
     * Encodes the OpenCV [Mat] to JPEG and uploads it synchronously with its scores.
     * @return A Pair containing a Boolean indicating success, and a String description/error message.
     */
    fun sendFrame(source: String, mat: Mat, score: FrameScore, jpegQuality: Int): Pair<Boolean, String?> {
        val service = apiService ?: return Pair(false, "Server address not configured")

        if (mat.empty()) {
            return Pair(false, "Cannot upload empty frame Mat")
        }

        var matOfByte: MatOfByte? = null
        var encodeParams: MatOfInt? = null

        try {
            // 1. Encode Mat to JPEG byte array using native encoder to save CPU cycles and GC churn
            matOfByte = MatOfByte()
            encodeParams = MatOfInt(Imgcodecs.IMWRITE_JPEG_QUALITY, jpegQuality)
            
            val encodeSuccess = Imgcodecs.imencode(".jpg", mat, matOfByte, encodeParams)
            if (!encodeSuccess) {
                return Pair(false, "Native JPEG encoding failed")
            }

            val jpegBytes = matOfByte.toArray()

            // 2. Wrap image bytes in MultipartBody.Part
            val requestFile = jpegBytes.toRequestBody("image/jpeg".toMediaTypeOrNull(), 0, jpegBytes.size)
            val imagePart = MultipartBody.Part.createFormData(
                "file", 
                "frame_${score.frameNumber}_q${score.quality}.jpg", 
                requestFile
            )

            // 3. Construct metadata JSON body part
            val timeString = dateFormat.format(Date(score.timestamp))
            val metadataDto = FrameMetadataDto(
                source = source,
                timestamp = timeString,
                quality = score.quality,
                blur = score.blur.toInt(),
                motion = score.motion.toInt(),
                exposure = score.brightness.toInt(),
                reflection = score.reflection.toInt()
            )
            val jsonMetadata = gson.toJson(metadataDto)
            val metadataPart = jsonMetadata.toRequestBody("application/json".toMediaTypeOrNull())

            // 4. Fire the network request
            val response = service.uploadFrame(imagePart, metadataPart).execute()
            return if (response.isSuccessful && response.body()?.success == true) {
                Pair(true, response.body()?.message ?: "Upload success")
            } else {
                val errorBody = response.errorBody()?.string()
                val responseMsg = response.body()?.message
                val errorDetail = responseMsg ?: errorBody ?: "HTTP Status ${response.code()}"
                Pair(false, errorDetail)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Network exception during upload: ${e.message}", e)
            return Pair(false, e.message ?: "Unknown network exception")
        } finally {
            // Release native allocations immediately
            matOfByte?.release()
            encodeParams?.release()
        }
    }

    companion object {
        private const val TAG = "UnoSender"
    }
}
