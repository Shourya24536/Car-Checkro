package com.oneplus.aicamera.enhancement

import com.oneplus.aicamera.utils.MatPool
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.util.ArrayList

/**
 * Configuration parameters for the image enhancement pipeline.
 */
data class EnhancementConfig(
    val isWhiteBalanceEnabled: Boolean = true,
    val isDenoiseEnabled: Boolean = true,
    val isClaheEnabled: Boolean = true,
    val isSharpenEnabled: Boolean = true,
    
    val denoiseKernelSize: Int = 3, // Must be odd (e.g., 3, 5)
    val claheClipLimit: Double = 2.0,
    val claheTileSize: Int = 8,
    val sharpenAmount: Float = 0.5f, // Weight of sharp edges (0.0 to 1.5)
    val gamma: Double = 1.0
)

/**
 * Handles image enhancement filters using OpenCV.
 * Executes steps in the optimal order: White Balance -> Denoise -> CLAHE -> Sharpen.
 */
class ImageEnhancer(private val matPool: MatPool) {

    /**
     * Enhances the source image [src] according to [config] and writes the output to [dst].
     * Reuse-friendly, allocating temporary buffers from the [MatPool] and recycling them.
     */
    fun enhance(src: Mat, dst: Mat, config: EnhancementConfig) {
        if (src.empty()) return

        var currentSrc = matPool.obtain()
        src.copyTo(currentSrc)

        val tempMat = matPool.obtain()

        try {
            // 1. White Balance
            if (config.isWhiteBalanceEnabled) {
                applyWhiteBalance(currentSrc, tempMat)
                tempMat.copyTo(currentSrc)
            }

            // 2. Denoise
            if (config.isDenoiseEnabled) {
                applyDenoise(currentSrc, tempMat, config.denoiseKernelSize)
                tempMat.copyTo(currentSrc)
            }

            // 3. CLAHE
            if (config.isClaheEnabled) {
                applyClahe(currentSrc, tempMat, config.claheClipLimit, config.claheTileSize)
                tempMat.copyTo(currentSrc)
            }

            // 4. Sharpen
            if (config.isSharpenEnabled) {
                applySharpen(currentSrc, tempMat, config.sharpenAmount)
                tempMat.copyTo(currentSrc)
            }

            // 5. Gamma Correction
            if (config.gamma != 1.0) {
                applyGammaCorrection(currentSrc, tempMat, config.gamma)
                tempMat.copyTo(currentSrc)
            }

            // Copy output to destination
            currentSrc.copyTo(dst)

        } finally {
            matPool.recycle(currentSrc)
            matPool.recycle(tempMat)
        }
    }

    /**
     * Balances color channels by scaling green and blue channels to match the mean of the red/global channel.
     */
    private fun applyWhiteBalance(src: Mat, dst: Mat) {
        val channels = ArrayList<Mat>()
        Core.split(src, channels)

        if (channels.size >= 3) {
            val meanB = Core.mean(channels[0]).`val`[0]
            val meanG = Core.mean(channels[1]).`val`[0]
            val meanR = Core.mean(channels[2]).`val`[0]
            val meanAvg = (meanB + meanG + meanR) / 3.0

            if (meanB > 0) Core.multiply(channels[0], Scalar((meanAvg / meanB).coerceIn(0.7, 1.3)), channels[0])
            if (meanG > 0) Core.multiply(channels[1], Scalar((meanAvg / meanG).coerceIn(0.7, 1.3)), channels[1])
            if (meanR > 0) Core.multiply(channels[2], Scalar((meanAvg / meanR).coerceIn(0.7, 1.3)), channels[2])

            Core.merge(channels, dst)
        } else {
            src.copyTo(dst)
        }

        // Release channel mats
        for (channel in channels) {
            channel.release()
        }
    }

    /**
     * Fast Gaussian blur for noise removal.
     */
    private fun applyDenoise(src: Mat, dst: Mat, kernelSize: Int) {
        val size = kernelSize.coerceAtLeast(3) or 1 // Force odd number
        Imgproc.GaussianBlur(src, dst, Size(size.toDouble(), size.toDouble()), 0.0)
    }

    /**
     * Applies CLAHE to the L channel after converting to LAB color space to preserve colors.
     */
    private fun applyClahe(src: Mat, dst: Mat, clipLimit: Double, tileSize: Int) {
        val labMat = matPool.obtain()
        Imgproc.cvtColor(src, labMat, Imgproc.COLOR_BGR2Lab)

        val labChannels = ArrayList<Mat>()
        Core.split(labMat, labChannels)

        if (labChannels.isNotEmpty()) {
            val lChannel = labChannels[0]
            val clahe = Imgproc.createCLAHE(clipLimit, Size(tileSize.toDouble(), tileSize.toDouble()))
            
            val enhancedL = matPool.obtain()
            clahe.apply(lChannel, enhancedL)
            
            // Swap back
            labChannels[0] = enhancedL
            Core.merge(labChannels, labMat)
            Imgproc.cvtColor(labMat, dst, Imgproc.COLOR_Lab2BGR)

            // Cleanup
            clahe.collectGarbage()
            matPool.recycle(enhancedL)
            lChannel.release() // Was split
        } else {
            src.copyTo(dst)
        }

        for (i in 1 until labChannels.size) {
            labChannels[i].release()
        }
        matPool.recycle(labMat)
    }

    /**
     * Unsharp masking sharpening filter: dst = src * (1 + amount) - blurred * amount
     */
    private fun applySharpen(src: Mat, dst: Mat, amount: Float) {
        if (amount <= 0.0f) {
            src.copyTo(dst)
            return
        }

        val blurred = matPool.obtain()
        Imgproc.GaussianBlur(src, blurred, Size(5.0, 5.0), 0.0)

        // Core.addWeighted(src, 1 + amount, blurred, -amount, gamma, dst)
        Core.addWeighted(src, 1.0 + amount.toDouble(), blurred, -amount.toDouble(), 0.0, dst)

        matPool.recycle(blurred)
    }

    /**
     * Applies Gamma Correction using an optimized 256-value Lookup Table (LUT).
     */
    private fun applyGammaCorrection(src: Mat, dst: Mat, gamma: Double) {
        val lut = Mat(1, 256, CvType.CV_8UC1)
        val lutArray = ByteArray(256)
        for (i in 0..255) {
            val v = Math.pow(i / 255.0, 1.0 / gamma) * 255.0
            lutArray[i] = v.coerceIn(0.0, 255.0).toInt().toByte()
        }
        lut.put(0, 0, lutArray)
        Core.LUT(src, lut, dst)
        lut.release()
    }
}
