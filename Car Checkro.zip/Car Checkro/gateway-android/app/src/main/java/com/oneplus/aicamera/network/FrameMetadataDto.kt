package com.oneplus.aicamera.network

import com.google.gson.annotations.SerializedName

/**
 * Data Transfer Object representing the JSON metadata payload sent to the UNO-Q receiver.
 * Includes the source camera identifier to distinguish dual-feed frames.
 */
data class FrameMetadataDto(
    @SerializedName("source")
    val source: String,             // Originating source: "Samsung_S23" or "OnePlus_15"

    @SerializedName("timestamp")
    val timestamp: String,
    
    @SerializedName("quality")
    val quality: Int,
    
    @SerializedName("blur")
    val blur: Int,
    
    @SerializedName("motion")
    val motion: Int,
    
    @SerializedName("exposure")
    val exposure: Int,
    
    @SerializedName("reflection")
    val reflection: Int
)
