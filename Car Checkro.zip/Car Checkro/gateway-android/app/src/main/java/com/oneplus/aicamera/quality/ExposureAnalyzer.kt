package com.oneplus.aicamera.quality

import com.oneplus.aicamera.utils.MatPool
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfFloat
import org.opencv.core.MatOfInt
import org.opencv.imgproc.Imgproc
import java.util.Collections

/**
 * Configuration limits for exposure validation.
 */
data class ExposureConfig(
    val minBrightness: Double = 40.0,
    val maxBrightness: Double = 220.0,
    val minDynamicRange: Double = 50.0
)

/**
 * Analyzes frame exposure metrics (mean brightness, histogram, dynamic range)
 * to reject extreme lighting conditions.
 */
class ExposureAnalyzer(private val matPool: MatPool) {

    /**
     * Measures exposure attributes. Returns a Triple containing:
     * - Average Brightness (0.0 to 255.0)
     * - Dynamic Range (0.0 to 255.0)
     * - Histogram values (FloatArray of size 256)
     */
    fun analyze(src: Mat): ExposureResult {
        if (src.empty()) {
            return ExposureResult(0.0, 0.0, FloatArray(256))
        }

        val gray = matPool.obtain()
        val hist = Mat()

        try {
            // Convert to grayscale
            if (src.channels() > 1) {
                Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY)
            } else {
                src.copyTo(gray)
            }

            // 1. Average Brightness
            val brightness = Core.mean(gray).`val`[0]

            // 2. Calculate 256-bin Histogram
            val images = Collections.singletonList(gray)
            val channels = MatOfInt(0)
            val histSize = MatOfInt(256)
            val ranges = MatOfFloat(0.0f, 256.0f)
            Imgproc.calcHist(images, channels, Mat(), hist, histSize, ranges)

            val histArray = FloatArray(256)
            hist.get(0, 0, histArray)

            // 3. Dynamic Range (Difference between 99th and 1st percentile of brightness to filter hot pixels)
            val totalPixels = gray.rows() * gray.cols().toDouble()
            var lowPercentile = 0.0
            var highPercentile = 255.0
            
            var pixelSum = 0.0
            for (i in 0..255) {
                pixelSum += histArray[i]
                if (pixelSum >= totalPixels * 0.01 && lowPercentile == 0.0) {
                    lowPercentile = i.toDouble()
                }
                if (pixelSum >= totalPixels * 0.99) {
                    highPercentile = i.toDouble()
                    break
                }
            }
            val dynamicRange = highPercentile - lowPercentile

            channels.release()
            histSize.release()
            ranges.release()

            return ExposureResult(brightness, dynamicRange, histArray)
        } catch (e: Exception) {
            return ExposureResult(0.0, 0.0, FloatArray(256))
        } finally {
            matPool.recycle(gray)
            hist.release()
        }
    }

    /**
     * Determines if a frame's exposure levels are acceptable.
     */
    fun isAcceptable(brightness: Double, dynamicRange: Double, config: ExposureConfig): Boolean {
        return brightness in config.minBrightness..config.maxBrightness && 
               dynamicRange >= config.minDynamicRange
    }
}

/**
 * Encapsulates the results of exposure analysis.
 */
data class ExposureResult(
    val averageBrightness: Double,
    val dynamicRange: Double,
    val histogram: FloatArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as ExposureResult
        if (averageBrightness != other.averageBrightness) return false
        if (dynamicRange != other.dynamicRange) return false
        return histogram.contentEquals(other.histogram)
    }

    override fun hashCode(): Int {
        var result = averageBrightness.hashCode()
        result = 31 * result + dynamicRange.hashCode()
        result = 31 * result + histogram.contentHashCode()
        return result
    }
}
