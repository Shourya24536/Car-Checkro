package com.oneplus.aicamera.blur

import com.oneplus.aicamera.utils.MatPool
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfDouble
import org.opencv.imgproc.Imgproc

/**
 * Handles detection of image blur using the Variance of Laplacian method.
 */
class BlurDetector(private val matPool: MatPool) {

    /**
     * Calculates the sharpness/blur score of the given frame.
     * Higher score indicates a sharper image; lower score indicates more blur.
     * Uses double precision (CV_64F) Laplacian for accurate variance estimation.
     */
    fun calculateBlurScore(src: Mat): Double {
        if (src.empty()) return 0.0

        val gray = matPool.obtain()
        val laplacian = matPool.obtain()
        val mean = MatOfDouble()
        val stdDev = MatOfDouble()

        try {
            // Convert to grayscale
            if (src.channels() > 1) {
                Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY)
            } else {
                src.copyTo(gray)
            }

            // Apply Laplacian operator
            Imgproc.Laplacian(gray, laplacian, CvType.CV_64F)

            // Calculate standard deviation and mean of the Laplacian
            Core.meanStdDev(laplacian, mean, stdDev)

            // Variance = standard deviation squared
            val sd = stdDev.get(0, 0)[0]
            return sd * sd
        } catch (e: Exception) {
            return 0.0
        } finally {
            matPool.recycle(gray)
            matPool.recycle(laplacian)
            mean.release()
            stdDev.release()
        }
    }

    /**
     * Checks if the blur score exceeds the configured threshold.
     */
    fun isSharp(score: Double, threshold: Double): Boolean {
        return score >= threshold
    }
}
