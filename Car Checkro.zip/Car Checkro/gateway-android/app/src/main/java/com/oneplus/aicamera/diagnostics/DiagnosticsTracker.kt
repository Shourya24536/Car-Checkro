package com.oneplus.aicamera.diagnostics

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Debug
import android.os.PowerManager
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Diagnostics state snapshot containing resource utilisation and performance metrics.
 */
data class DiagnosticsSnapshot(
    val batteryTemp: Double,
    val thermalStatus: String,
    val jvmHeapUsedMb: Double,
    val nativeHeapUsedMb: Double,
    val availableProcessors: Int,
    val avgProcessingTimeMs: Double,
    val avgUploadTimeMs: Double
)

/**
 * Monitors hardware diagnostics and pipeline execution speeds on Snapdragon platforms.
 * Tracks memory leaks, CPU metrics, temperature, and thermal throttling states.
 */
class DiagnosticsTracker(private val context: Context) {

    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager

    // Dynamic state streams
    private val _thermalStatus = MutableStateFlow("UNKNOWN")
    val thermalStatus: StateFlow<String> = _thermalStatus.asStateFlow()

    private val _batteryTemp = MutableStateFlow(0.0)
    val batteryTemp: StateFlow<Double> = _batteryTemp.asStateFlow()

    // Sliding window lists for latency averaging
    private val processingWindow = ArrayList<Long>()
    private val uploadWindow = ArrayList<Long>()
    private val maxWindowSize = 100

    init {
        setupThermalListener()
    }

    /**
     * Captures and returns a snapshot of the current device resources and pipeline averages.
     */
    fun captureSnapshot(): DiagnosticsSnapshot {
        updateBatteryTemperature()

        val runtime = Runtime.getRuntime()
        val jvmUsed = (runtime.totalMemory() - runtime.freeMemory()).toDouble() / (1024.0 * 1024.0)
        val nativeUsed = Debug.getNativeHeapAllocatedSize().toDouble() / (1024.0 * 1024.0)

        val avgProc = getAvgProcessingTime()
        val avgUpload = getAvgUploadTime()

        return DiagnosticsSnapshot(
            batteryTemp = _batteryTemp.value,
            thermalStatus = _thermalStatus.value,
            jvmHeapUsedMb = jvmUsed,
            nativeHeapUsedMb = nativeUsed,
            availableProcessors = runtime.availableProcessors(),
            avgProcessingTimeMs = avgProc,
            avgUploadTimeMs = avgUpload
        )
    }

    /**
     * Records a frame processing latency sample.
     */
    @Synchronized
    fun recordProcessingLatency(timeMs: Long) {
        processingWindow.add(timeMs)
        if (processingWindow.size > maxWindowSize) {
            processingWindow.removeAt(0)
        }
    }

    /**
     * Records a frame upload latency sample.
     */
    @Synchronized
    fun recordUploadLatency(timeMs: Long) {
        uploadWindow.add(timeMs)
        if (uploadWindow.size > maxWindowSize) {
            uploadWindow.removeAt(0)
        }
    }

    @Synchronized
    fun getAvgProcessingTime(): Double {
        return if (processingWindow.isEmpty()) 0.0 else processingWindow.average()
    }

    @Synchronized
    fun getAvgUploadTime(): Double {
        return if (uploadWindow.isEmpty()) 0.0 else uploadWindow.average()
    }

    private fun updateBatteryTemperature() {
        try {
            val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = context.registerReceiver(null, intentFilter)
            if (batteryStatus != null) {
                val temp = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
                _batteryTemp.value = temp / 10.0 // BatteryManager returns temperature in tenths of a degree Celsius
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to read battery temperature: ${e.message}")
        }
    }

    private fun setupThermalListener() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && powerManager != null) {
            _thermalStatus.value = thermalLevelToString(powerManager.currentThermalStatus)
            
            try {
                powerManager.addThermalStatusListener(context.mainExecutor) { status ->
                    val statusStr = thermalLevelToString(status)
                    _thermalStatus.value = statusStr
                    Log.w(TAG, "Thermal Status Changed: $statusStr")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to register thermal status listener: ${e.message}")
            }
        } else {
            _thermalStatus.value = "UNSUPPORTED"
        }
    }

    private fun thermalLevelToString(level: Int): String {
        return when (level) {
            PowerManager.THERMAL_STATUS_NONE -> "NONE (Normal)"
            PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT (Minor Throttling)"
            PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"
            PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE (Throttling CPU/GPU)"
            PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL (Throttling Screen/NPU)"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "EMERGENCY (Shutdown Imminent)"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "SHUTDOWN"
            else -> "UNKNOWN"
        }
    }

    companion object {
        private const val TAG = "DiagnosticsTracker"
    }
}
