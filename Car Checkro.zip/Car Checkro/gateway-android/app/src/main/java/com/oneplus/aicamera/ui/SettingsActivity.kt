package com.oneplus.aicamera.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.oneplus.aicamera.communication.receiver.CameraSourceType
import com.oneplus.aicamera.databinding.ActivitySettingsBinding
import com.oneplus.aicamera.utils.SettingsManager

/**
 * Settings configuration screen enabling customization of thresholds, host addresses,
 * active camera modes, and gamma correction factor.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var settingsManager: SettingsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settingsManager = SettingsManager(this)

        setupToolbar()
        loadSettings()

        binding.btnSave.setOnClickListener {
            saveSettings()
        }
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    private fun loadSettings() {
        binding.etHost.setText(settingsManager.serverHost)
        binding.etPort.setText(settingsManager.serverPort.toString())
        binding.etStreamUrl.setText(settingsManager.streamUrl)
        
        binding.etBlur.setText(settingsManager.blurThreshold.toString())
        binding.etMotion.setText(settingsManager.motionThreshold.toString())
        binding.etJpegQuality.setText(settingsManager.jpegQuality.toString())
        binding.etGamma.setText(settingsManager.gamma.toString())
        
        binding.etReflPercent.setText(settingsManager.maxReflectionPercent.toString())
        binding.etReflCount.setText(settingsManager.maxReflectionCount.toString())
        binding.etReflBlob.setText(settingsManager.maxLargestBlobArea.toString())
        
        binding.switchEnhancement.isChecked = settingsManager.enableEnhancement
        binding.switchUseAi.isChecked = settingsManager.useAiEstimator

        // Load camera source mode
        when (settingsManager.cameraSource) {
            CameraSourceType.SAMSUNG_S23.ordinal -> binding.rbS23.isChecked = true
            CameraSourceType.ONEPLUS_CAMERA.ordinal -> binding.rbOneplus.isChecked = true
            CameraSourceType.DUAL_CAMERA.ordinal -> binding.rbDual.isChecked = true
            CameraSourceType.AUTO_DETECT.ordinal -> binding.rbAuto.isChecked = true
        }
    }

    private fun saveSettings() {
        try {
            val host = binding.etHost.text.toString().trim()
            val port = binding.etPort.text.toString().toIntOrNull() ?: 8000
            val streamUrl = binding.etStreamUrl.text.toString().trim()
            
            val blur = binding.etBlur.text.toString().toDoubleOrNull() ?: 80.0
            val motion = binding.etMotion.text.toString().toDoubleOrNull() ?: 2.0
            val jpegQuality = binding.etJpegQuality.text.toString().toIntOrNull() ?: 85
            val gamma = binding.etGamma.text.toString().toDoubleOrNull() ?: 1.0
            
            val reflPercent = binding.etReflPercent.text.toString().toDoubleOrNull() ?: 5.0
            val reflCount = binding.etReflCount.text.toString().toIntOrNull() ?: 15
            val reflBlob = binding.etReflBlob.text.toString().toDoubleOrNull() ?: 2000.0

            if (host.isEmpty() || streamUrl.isEmpty()) {
                Toast.makeText(this, "Host and Stream URL cannot be empty!", Toast.LENGTH_SHORT).show()
                return
            }

            // Save camera source selection
            val sourceMode = when (binding.rgCameraSource.checkedRadioButtonId) {
                binding.rbS23.id -> CameraSourceType.SAMSUNG_S23.ordinal
                binding.rbOneplus.id -> CameraSourceType.ONEPLUS_CAMERA.ordinal
                binding.rbDual.id -> CameraSourceType.DUAL_CAMERA.ordinal
                binding.rbAuto.id -> CameraSourceType.AUTO_DETECT.ordinal
                else -> CameraSourceType.DUAL_CAMERA.ordinal
            }

            settingsManager.serverHost = host
            settingsManager.serverPort = port
            settingsManager.streamUrl = streamUrl
            
            settingsManager.blurThreshold = blur
            settingsManager.motionThreshold = motion
            settingsManager.jpegQuality = jpegQuality.coerceIn(1, 100)
            settingsManager.gamma = gamma.coerceIn(0.1, 5.0)
            
            settingsManager.maxReflectionPercent = reflPercent
            settingsManager.maxReflectionCount = reflCount
            settingsManager.maxLargestBlobArea = reflBlob
            
            settingsManager.enableEnhancement = binding.switchEnhancement.isChecked
            settingsManager.useAiEstimator = binding.switchUseAi.isChecked
            settingsManager.cameraSource = sourceMode

            Toast.makeText(this, "Configurations saved successfully", Toast.LENGTH_SHORT).show()
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to save: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
