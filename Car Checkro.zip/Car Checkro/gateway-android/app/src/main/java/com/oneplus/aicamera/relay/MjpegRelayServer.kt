package com.oneplus.aicamera.relay

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.opencv.core.Mat
import org.opencv.core.MatOfByte
import org.opencv.core.MatOfInt
import org.opencv.imgcodecs.Imgcodecs
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Embedded MJPEG HTTP relay server.
 *
 * The OnePlus AI Camera Gateway receives an MJPEG stream from the Samsung S23,
 * filters out blurry / over-exposed / glare-affected frames using the processing
 * pipeline, then re-streams ONLY the accepted frames through this server.
 *
 * The UNO-Q dent_detector C++ program can then point cv::VideoCapture at:
 *   http://<OnePlus-IP>:<port>/stream
 * and receive a clean, pre-filtered video feed without any changes to its C++ code.
 *
 * Usage:
 *   val relay = MjpegRelayServer(port = 8090)
 *   relay.start()
 *
 *   // In the pipeline callback, when a frame is accepted:
 *   relay.pushFrame(enhancedMat, jpegQuality = 85)
 *
 *   relay.stop()
 */
class MjpegRelayServer(
    private val port: Int = 8090,
    private val maxClients: Int = 4
) {

    private val scope = CoroutineScope(Dispatchers.IO)
    private var serverJob: Job? = null
    private var serverSocket: ServerSocket? = null

    private val running = AtomicBoolean(false)

    /** Thread-safe list of active client output streams. */
    private val clients = CopyOnWriteArrayList<ClientConnection>()

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    /**
     * Starts the MJPEG relay server on [port].
     * Non-blocking — runs on an IO coroutine.
     */
    fun start() {
        if (running.getAndSet(true)) {
            Log.w(TAG, "Relay server is already running on port $port")
            return
        }

        serverJob = scope.launch {
            try {
                val ss = ServerSocket(port)
                serverSocket = ss
                Log.i(TAG, "MJPEG relay server started on port $port — waiting for UNO-Q clients")

                while (running.get()) {
                    try {
                        val clientSocket: Socket = ss.accept()
                        handleNewClient(clientSocket)
                    } catch (e: Exception) {
                        if (running.get()) {
                            Log.e(TAG, "Error accepting client: ${e.message}")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "MJPEG relay server error: ${e.message}", e)
            } finally {
                running.set(false)
                Log.i(TAG, "MJPEG relay server stopped.")
            }
        }
    }

    /** Stops the relay server and disconnects all clients. */
    fun stop() {
        running.set(false)
        clients.forEach { it.close() }
        clients.clear()
        try { serverSocket?.close() } catch (_: Exception) {}
        serverSocket = null
        serverJob?.cancel()
        serverJob = null
        Log.i(TAG, "MJPEG relay server shut down cleanly.")
    }

    // -------------------------------------------------------------------------
    // Frame injection
    // -------------------------------------------------------------------------

    /**
     * Encodes [frame] as JPEG and broadcasts it to all connected MJPEG clients.
     * Call this from your pipeline's accepted-frame callback.
     *
     * This is thread-safe: the Mat is encoded here and immediately released;
     * the caller retains ownership and can recycle it.
     *
     * @param frame       The accepted, enhanced OpenCV [Mat] (BGR).
     * @param jpegQuality JPEG encoding quality (1-100, default 85).
     */
    fun pushFrame(frame: Mat, jpegQuality: Int = 85) {
        if (clients.isEmpty()) return      // No clients — skip encoding
        if (frame.empty()) return

        val matOfByte = MatOfByte()
        val params = MatOfInt(Imgcodecs.IMWRITE_JPEG_QUALITY, jpegQuality)

        try {
            val ok = Imgcodecs.imencode(".jpg", frame, matOfByte, params)
            if (!ok) {
                Log.w(TAG, "pushFrame: JPEG encoding failed — frame skipped")
                return
            }

            val jpegBytes = matOfByte.toArray()
            broadcastFrame(jpegBytes)

        } catch (e: Exception) {
            Log.e(TAG, "pushFrame error: ${e.message}")
        } finally {
            matOfByte.release()
            params.release()
        }
    }

    // -------------------------------------------------------------------------
    // Internal helpers
    // -------------------------------------------------------------------------

    private fun handleNewClient(socket: Socket) {
        if (clients.size >= maxClients) {
            Log.w(TAG, "Max client limit ($maxClients) reached — rejecting ${socket.inetAddress}")
            try { socket.close() } catch (_: Exception) {}
            return
        }

        scope.launch {
            val conn = ClientConnection(socket)
            try {
                Log.i(TAG, "UNO-Q client connected: ${socket.inetAddress}:${socket.port}")
                conn.sendHttpMjpegHeader()
                clients.add(conn)
                // Keep the coroutine alive while socket is open (blocking on client disconnect)
                conn.keepAlive()
            } catch (e: Exception) {
                Log.d(TAG, "Client ${socket.inetAddress} disconnected: ${e.message}")
            } finally {
                clients.remove(conn)
                conn.close()
                Log.i(TAG, "UNO-Q client disconnected: ${socket.inetAddress}")
            }
        }
    }

    private fun broadcastFrame(jpegBytes: ByteArray) {
        val deadClients = mutableListOf<ClientConnection>()

        for (client in clients) {
            try {
                client.sendFrame(jpegBytes)
            } catch (e: Exception) {
                Log.d(TAG, "Client write error — removing: ${e.message}")
                deadClients.add(client)
            }
        }

        deadClients.forEach { dead ->
            clients.remove(dead)
            dead.close()
        }
    }

    // -------------------------------------------------------------------------
    // ClientConnection
    // -------------------------------------------------------------------------

    private inner class ClientConnection(private val socket: Socket) {

        private val out: OutputStream = socket.getOutputStream()
        private val input = socket.getInputStream()

        /** Sends the HTTP 200 response and MJPEG Content-Type header. */
        fun sendHttpMjpegHeader() {
            val header = buildString {
                append("HTTP/1.1 200 OK\r\n")
                append("Content-Type: multipart/x-mixed-replace; boundary=mjpeg_frame\r\n")
                append("Cache-Control: no-cache\r\n")
                append("Connection: close\r\n")
                append("Pragma: no-cache\r\n")
                append("\r\n")
            }
            out.write(header.toByteArray(Charsets.US_ASCII))
            out.flush()
        }

        /** Writes one JPEG frame as a MJPEG multipart body part. */
        fun sendFrame(jpegBytes: ByteArray) {
            val partHeader = buildString {
                append("--mjpeg_frame\r\n")
                append("Content-Type: image/jpeg\r\n")
                append("Content-Length: ${jpegBytes.size}\r\n")
                append("\r\n")
            }
            out.write(partHeader.toByteArray(Charsets.US_ASCII))
            out.write(jpegBytes)
            out.write("\r\n".toByteArray(Charsets.US_ASCII))
            out.flush()
        }

        /**
         * Blocks until the client disconnects (reads -1) or an exception is thrown.
         * This keeps the coroutine alive so we receive disconnect notifications.
         */
        fun keepAlive() {
            try {
                while (!socket.isClosed) {
                    if (input.read() == -1) break
                }
            } catch (_: Exception) {}
        }

        fun close() {
            try { socket.close() } catch (_: Exception) {}
        }
    }

    // -------------------------------------------------------------------------
    // Status
    // -------------------------------------------------------------------------

    val isRunning: Boolean get() = running.get()
    val connectedClientCount: Int get() = clients.size
    val streamUrl: String get() = "http://<OnePlus-IP>:$port/stream"

    companion object {
        private const val TAG = "MjpegRelayServer"
    }
}
