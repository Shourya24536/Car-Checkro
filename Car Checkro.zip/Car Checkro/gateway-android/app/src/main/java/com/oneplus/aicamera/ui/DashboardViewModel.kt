package com.oneplus.aicamera.ui

import android.app.Application
import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.viewModelScope
import com.oneplus.aicamera.blur.BlurDetector
import com.oneplus.aicamera.communication.receiver.CameraSourceManager
import com.oneplus.aicamera.communication.receiver.CameraSourceType
import com.oneplus.aicamera.communication.sender.UnoSender
import com.oneplus.aicamera.diagnostics.DiagnosticsSnapshot
import com.oneplus.aicamera.diagnostics.DiagnosticsTracker
import com.oneplus.aicamera.enhancement.ImageEnhancer
import com.oneplus.aicamera.models.Frame
import com.oneplus.aicamera.models.FrameScore
import com.oneplus.aicamera.motion.MotionDetector
import com.oneplus.aicamera.pipeline.FrameProcessingPipeline
import com.oneplus.aicamera.pipeline.PipelineConfig
import com.oneplus.aicamera.pipeline.PipelineListener
import com.oneplus.aicamera.quality.EstimatorFactory
import com.oneplus.aicamera.quality.ExposureAnalyzer
import com.oneplus.aicamera.reflection.ReflectionDetector
import com.oneplus.aicamera.repository.FrameRepository
import com.oneplus.aicamera.relay.RelayCoordinator
import com.oneplus.aicamera.utils.FrameBuffer
import com.oneplus.aicamera.utils.MatPool
import com.oneplus.aicamera.utils.SettingsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import java.util.concurrent.atomic.AtomicInteger

/**
 * ViewModel orchestrating dual streams connection, parallel pipelines execution,
 * diagnostics, and repository uploads.
 */
class DashboardViewModel(application: Application) : AndroidViewModel(application), PipelineListener {

    private val settingsManager = SettingsManager(application)
    private val matPool = MatPool(maxPoolSize = 30)

    // Separate buffers for independent motion estimation and history caching
    private val s23FrameBuffer = FrameBuffer(capacity = 5, matPool = matPool)
    private val oneplusFrameBuffer = FrameBuffer(capacity = 5, matPool = matPool)
    
    // CV components
    private val enhancer = ImageEnhancer(matPool)
    private val blurDetector = BlurDetector(matPool)
    private val motionDetector = MotionDetector(matPool)
    private val exposureAnalyzer = ExposureAnalyzer(matPool)
    private val reflectionDetector = ReflectionDetector(matPool)
    
    private val unoSender = UnoSender()
    val repository = FrameRepository(unoSender, matPool)
    private val diagnosticsTracker = DiagnosticsTracker(application)

    /**
     * MJPEG relay: re-streams accepted Samsung frames on port [settingsManager.mjpegRelayPort]
     * so the UNO-Q dent_detector can connect via cv::VideoCapture.
     */
    val relay = RelayCoordinator(relayPort = settingsManager.mjpegRelayPort)

    private lateinit var cameraSourceManager: CameraSourceManager

    // Two completely independent processing pipelines
    private var s23Pipeline: FrameProcessingPipeline
    private var oneplusPipeline: FrameProcessingPipeline

    // Active state streams
    private val _isStreaming = MutableStateFlow(false)
    val isStreaming: StateFlow<Boolean> = _isStreaming.asStateFlow()

    // Previews
    private val _s23PreviewBitmap = MutableStateFlow<Bitmap?>(null)
    val s23PreviewBitmap: StateFlow<Bitmap?> = _s23PreviewBitmap.asStateFlow()

    private val _oneplusPreviewBitmap = MutableStateFlow<Bitmap?>(null)
    val oneplusPreviewBitmap: StateFlow<Bitmap?> = _oneplusPreviewBitmap.asStateFlow()

    private val _lastUploadedBitmap = MutableStateFlow<Bitmap?>(null)
    val lastUploadedBitmap: StateFlow<Bitmap?> = _lastUploadedBitmap.asStateFlow()

    // S23 pipeline variables
    private val _s23FrameScore = MutableStateFlow<FrameScore?>(null)
    val s23FrameScore: StateFlow<FrameScore?> = _s23FrameScore.asStateFlow()

    private val _s23IsFrameAccepted = MutableStateFlow(true)
    val s23IsFrameAccepted: StateFlow<Boolean> = _s23IsFrameAccepted.asStateFlow()

    private val _s23RejectionReason = MutableStateFlow<String?>(null)
    val s23RejectionReason: StateFlow<String?> = _s23RejectionReason.asStateFlow()

    private val _s23Fps = MutableStateFlow(0)
    val s23Fps: StateFlow<Int> = _s23Fps.asStateFlow()

    private val _s23RejectedCount = MutableStateFlow(0)
    val s23RejectedCount: StateFlow<Int> = _s23RejectedCount.asStateFlow()

    private val _s23LatencyVal = MutableStateFlow(0L)
    val s23LatencyVal: StateFlow<Long> = _s23LatencyVal.asStateFlow()

    // OnePlus pipeline variables
    private val _oneplusFrameScore = MutableStateFlow<FrameScore?>(null)
    val oneplusFrameScore: StateFlow<FrameScore?> = _oneplusFrameScore.asStateFlow()

    private val _oneplusIsFrameAccepted = MutableStateFlow(true)
    val oneplusIsFrameAccepted: StateFlow<Boolean> = _oneplusIsFrameAccepted.asStateFlow()

    private val _oneplusRejectionReason = MutableStateFlow<String?>(null)
    val oneplusRejectionReason: StateFlow<String?> = _oneplusRejectionReason.asStateFlow()

    private val _oneplusFps = MutableStateFlow(0)
    val oneplusFps: StateFlow<Int> = _oneplusFps.asStateFlow()

    private val _oneplusRejectedCount = MutableStateFlow(0)
    val oneplusRejectedCount: StateFlow<Int> = _oneplusRejectedCount.asStateFlow()

    private val _oneplusLatencyVal = MutableStateFlow(0L)
    val oneplusLatencyVal: StateFlow<Long> = _oneplusLatencyVal.asStateFlow()

    // Telemetry Debug stats
    private val _activeS23AvgRgb = MutableStateFlow(doubleArrayOf(0.0, 0.0, 0.0))
    val activeS23AvgRgb: StateFlow<DoubleArray> = _activeS23AvgRgb.asStateFlow()

    private val _activeOneplusAvgRgb = MutableStateFlow(doubleArrayOf(0.0, 0.0, 0.0))
    val activeOneplusAvgRgb: StateFlow<DoubleArray> = _activeOneplusAvgRgb.asStateFlow()

    private val _s23Histogram = MutableStateFlow(FloatArray(256))
    val s23Histogram: StateFlow<FloatArray> = _s23Histogram.asStateFlow()

    private val _oneplusHistogram = MutableStateFlow(FloatArray(256))
    val oneplusHistogram: StateFlow<FloatArray> = _oneplusHistogram.asStateFlow()

    private val _diagnostics = MutableStateFlow<DiagnosticsSnapshot?>(null)
    val diagnostics: StateFlow<DiagnosticsSnapshot?> = _diagnostics.asStateFlow()

    // Reusable bitmaps for performance
    private var reusableS23PreviewBmp: Bitmap? = null
    private var reusableS23UploadBmp: Bitmap? = null
    private var reusableOneplusPreviewBmp: Bitmap? = null
    private var reusableOneplusUploadBmp: Bitmap? = null

    // Dual counters
    private val s23FrameCount = AtomicInteger(0)
    private val oneplusFrameCount = AtomicInteger(0)

    private var fpsJob: Job? = null
    private var diagnosticsJob: Job? = null
    private var streamCollectJob: Job? = null

    init {
        // Build the s23 pipeline
        s23Pipeline = FrameProcessingPipeline(
            matPool = matPool,
            frameBuffer = s23FrameBuffer,
            enhancer = enhancer,
            blurDetector = blurDetector,
            motionDetector = motionDetector,
            exposureAnalyzer = exposureAnalyzer,
            reflectionDetector = reflectionDetector,
            qualityEstimator = EstimatorFactory.create(false, com.oneplus.aicamera.quality.EstimatorConfig()),
            config = settingsManager.getPipelineConfig()
        )
        s23Pipeline.setListener(this)

        // Build the oneplus pipeline
        oneplusPipeline = FrameProcessingPipeline(
            matPool = matPool,
            frameBuffer = oneplusFrameBuffer,
            enhancer = enhancer,
            blurDetector = blurDetector,
            motionDetector = motionDetector,
            exposureAnalyzer = exposureAnalyzer,
            reflectionDetector = reflectionDetector,
            qualityEstimator = EstimatorFactory.create(false, com.oneplus.aicamera.quality.EstimatorConfig()),
            config = settingsManager.getPipelineConfig()
        )
        oneplusPipeline.setListener(this)
    }

    /**
     * Initializes the CameraSourceManager once the LifecycleOwner is available.
     */
    fun initSourceManager(lifecycleOwner: LifecycleOwner) {
        cameraSourceManager = CameraSourceManager(getApplication(), lifecycleOwner)
    }

    /**
     * Refreshes settings configurations in both pipelines and repository.
     */
    fun refreshConfig() {
        val pipeConfig = settingsManager.getPipelineConfig()
        s23Pipeline.config = pipeConfig
        oneplusPipeline.config = pipeConfig

        // Dynamically update estimator thresholds based on saved blur/motion/glare configurations
        val ruleConfig = com.oneplus.aicamera.quality.EstimatorConfig(
            blurOptimal = settingsManager.blurThreshold * 2.0,
            blurMin = settingsManager.blurThreshold * 0.5,
            motionMax = settingsManager.motionThreshold * 2.0,
            reflectionMax = settingsManager.maxReflectionPercent * 2.0
        )
        
        s23Pipeline.qualityEstimator = EstimatorFactory.create(settingsManager.useAiEstimator, ruleConfig)
        oneplusPipeline.qualityEstimator = EstimatorFactory.create(settingsManager.useAiEstimator, ruleConfig)

        // Pass settings to Repository
        repository.jpegQuality = settingsManager.jpegQuality
        repository.updateServerConfig(settingsManager.serverHost, settingsManager.serverPort)
        Log.d(TAG, "Config refreshed: Host=${settingsManager.serverHost}:${settingsManager.serverPort}")
    }

    fun toggleStream() {
        if (_isStreaming.value) {
            stopStream()
        } else {
            startStream()
        }
    }

    private fun startStream() {
        if (!::cameraSourceManager.isInitialized) {
            Log.e(TAG, "CameraSourceManager is not initialized! Pass lifecycle owner first.")
            return
        }
        refreshConfig()
        _isStreaming.value = true
        s23FrameCount.set(0)
        oneplusFrameCount.set(0)

        // Start the MJPEG relay so the UNO-Q can connect
        relay.start()
        Log.i(TAG, "MJPEG relay started on port ${settingsManager.mjpegRelayPort}")

        val selectedSource = CameraSourceType.values()[settingsManager.cameraSource]

        // Start capture feeds
        cameraSourceManager.start(
            mode = selectedSource,
            streamUrl = settingsManager.streamUrl,
            serverHost = settingsManager.serverHost,
            serverPort = settingsManager.serverPort
        )

        // Bind parallel collection coroutines
        streamCollectJob = viewModelScope.launch(Dispatchers.Default) {
            launch {
                cameraSourceManager.s23FrameFlow.collect { frame ->
                    s23FrameCount.incrementAndGet()
                    s23Pipeline.process(frame)
                }
            }
            launch {
                cameraSourceManager.oneplusFrameFlow.collect { frame ->
                    oneplusFrameCount.incrementAndGet()
                    oneplusPipeline.process(frame)
                }
            }
        }

        // Start FPS tracking loop
        fpsJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                delay(1000)
                _s23Fps.value = s23FrameCount.getAndSet(0)
                _oneplusFps.value = oneplusFrameCount.getAndSet(0)
            }
        }

        // Start Diagnostics reporting loop
        diagnosticsJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                val snapshot = diagnosticsTracker.captureSnapshot()
                _diagnostics.value = snapshot
                delay(1000)
            }
        }
    }

    private fun stopStream() {
        _isStreaming.value = false
        _s23Fps.value = 0
        _oneplusFps.value = 0
        
        streamCollectJob?.cancel()
        streamCollectJob = null
        
        fpsJob?.cancel()
        fpsJob = null
        
        diagnosticsJob?.cancel()
        diagnosticsJob = null

        if (::cameraSourceManager.isInitialized) {
            cameraSourceManager.stop()
        }

        // Stop the MJPEG relay — disconnects UNO-Q client cleanly
        relay.stop()
        
        s23FrameBuffer.clear()
        oneplusFrameBuffer.clear()
        
        _s23PreviewBitmap.value = null
        _oneplusPreviewBitmap.value = null
    }

    /**
     * Implements [PipelineListener]. Processes outputs in background coroutines.
     */
    override fun onFrameProcessed(
        originalFrame: Frame,
        enhancedMat: Mat,
        score: FrameScore,
        isAccepted: Boolean,
        rejectionReason: String?
    ) {
        val isS23 = originalFrame.source == "Samsung_S23"

        viewModelScope.launch(Dispatchers.Default) {
            if (isS23) {
                _s23FrameScore.value = score
                _s23IsFrameAccepted.value = isAccepted
                _s23RejectionReason.value = rejectionReason
                _s23LatencyVal.value = score.processingTime
                diagnosticsTracker.recordProcessingLatency(score.processingTime)

                val previewBmp = convertMatToBitmap(enhancedMat, isPreview = true, isS23 = true)
                if (previewBmp != null) {
                    _s23PreviewBitmap.value = previewBmp
                }
            } else {
                _oneplusFrameScore.value = score
                _oneplusIsFrameAccepted.value = isAccepted
                _oneplusRejectionReason.value = rejectionReason
                _oneplusLatencyVal.value = score.processingTime
                diagnosticsTracker.recordProcessingLatency(score.processingTime)

                val previewBmp = convertMatToBitmap(enhancedMat, isPreview = true, isS23 = false)
                if (previewBmp != null) {
                    _oneplusPreviewBitmap.value = previewBmp
                }
            }

            if (isAccepted) {
                // Track upload times
                diagnosticsTracker.recordUploadLatency(repository.lastUploadTimeMs.value)
                
                val uploadBmp = convertMatToBitmap(enhancedMat, isPreview = false, isS23 = isS23)
                if (uploadBmp != null) {
                    _lastUploadedBitmap.value = uploadBmp
                }

                // Dispatch thread-safe frame to Repository upload channel
                repository.enqueueUpload(originalFrame.source, enhancedMat, score)

                // Forward accepted Samsung frames to the MJPEG relay → UNO-Q
                // Only S23 frames are relayed (single high-quality input for dent detection)
                if (isS23) {
                    relay.pushFrame(enhancedMat, score, settingsManager.jpegQuality)
                }
            } else {
                if (isS23) {
                    _s23RejectedCount.value = _s23RejectedCount.value + 1
                } else {
                    _oneplusRejectedCount.value = _oneplusRejectedCount.value + 1
                }
            }
        }
    }

    /**
     * Convers OpenCV Mat to Bitmap, reusing existing Bitmap memory to prevent GC allocations.
     * Integrates BGR-to-RGBA conversion to fix preview color space issues.
     */
    private suspend fun convertMatToBitmap(mat: Mat, isPreview: Boolean, isS23: Boolean): Bitmap? = withContext(Dispatchers.Default) {
        if (mat.empty()) return@withContext null
        try {
            val width = mat.cols()
            val height = mat.rows()

            var targetBmp = if (isS23) {
                if (isPreview) reusableS23PreviewBmp else reusableS23UploadBmp
            } else {
                if (isPreview) reusableOneplusPreviewBmp else reusableOneplusUploadBmp
            }

            if (targetBmp == null || targetBmp.width != width || targetBmp.height != height) {
                targetBmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                if (isS23) {
                    if (isPreview) reusableS23PreviewBmp = targetBmp else reusableS23UploadBmp = targetBmp
                } else {
                    if (isPreview) reusableOneplusPreviewBmp = targetBmp else reusableOneplusUploadBmp = targetBmp
                }
            }

            // CRITICAL FIX: Convert BGR (OpenCV default) to RGBA (Android Bitmap default)
            val rgbaMat = matPool.obtain()
            Imgproc.cvtColor(mat, rgbaMat, Imgproc.COLOR_BGR2RGBA)
            Utils.matToBitmap(rgbaMat, targetBmp)
            matPool.recycle(rgbaMat)

            // Compute statistics (average RGB and histogram) for debugging page
            computeDebugStats(mat, isS23)

            return@withContext targetBmp
        } catch (e: Exception) {
            Log.e(TAG, "Error in JNI matToBitmap conversion: ${e.message}")
            return@withContext null
        }
    }

    /**
     * Computes channel average intensities and 256-bin grayscale histogram.
     */
    private fun computeDebugStats(mat: Mat, isS23: Boolean) {
        try {
            // 1. Calculate Average RGB (mat is BGR)
            val meanVal = Core.mean(mat)
            val b = meanVal.`val`[0]
            val g = meanVal.`val`[1]
            val r = meanVal.`val`[2]
            val rgbArray = doubleArrayOf(r, g, b)

            if (isS23) {
                _activeS23AvgRgb.value = rgbArray
                DebugTelemetry.activeS23AvgRgb.value = rgbArray
            } else {
                _activeOneplusAvgRgb.value = rgbArray
                DebugTelemetry.activeOneplusAvgRgb.value = rgbArray
            }

            // 2. Calculate Grayscale Histogram
            val gray = Mat()
            Imgproc.cvtColor(mat, gray, Imgproc.COLOR_BGR2GRAY)
            val hist = Mat()
            val images = ArrayList<Mat>()
            images.add(gray)
            
            val channels = org.opencv.core.MatOfInt(0)
            val mask = Mat()
            val histSize = org.opencv.core.MatOfInt(256)
            val ranges = org.opencv.core.MatOfFloat(0f, 256f)
            
            Imgproc.calcHist(images, channels, mask, hist, histSize, ranges)
            val histArray = FloatArray(256)
            hist.get(0, 0, histArray)
            
            if (isS23) {
                _s23Histogram.value = histArray
                DebugTelemetry.s23Histogram.value = histArray
            } else {
                _oneplusHistogram.value = histArray
                DebugTelemetry.oneplusHistogram.value = histArray
            }
            
            gray.release()
            hist.release()
            channels.release()
            mask.release()
            histSize.release()
            ranges.release()
        } catch (e: Exception) {
            Log.e(TAG, "Error calculating debug histogram: ${e.message}")
        }
    }

    fun getActiveCameraMode(): CameraSourceType {
        return CameraSourceType.values()[settingsManager.cameraSource]
    }

    override fun onCleared() {
        super.onCleared()
        stopStream()
        matPool.clear()
    }

    companion object {
        private const val TAG = "DashboardViewModel"
    }
}
