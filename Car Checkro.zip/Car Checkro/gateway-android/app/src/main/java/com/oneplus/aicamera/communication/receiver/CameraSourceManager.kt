package com.oneplus.aicamera.communication.receiver

import android.content.Context
import android.util.Log
import androidx.lifecycle.LifecycleOwner
import com.oneplus.aicamera.models.Frame
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URI

/**
 * Camera source selection modes.
 */
enum class CameraSourceType {
    SAMSUNG_S23,
    ONEPLUS_CAMERA,
    DUAL_CAMERA,
    AUTO_DETECT
}

/**
 * Coordinates and directs frame collection from Samsung S23 streams and OnePlus CameraX inputs.
 * Supports independent streams, parallel dual mode, and network-reachability auto-fallback.
 */
class CameraSourceManager(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner
) {
    private val scope = CoroutineScope(Dispatchers.Default)

    // Separate hot flows for both sources
    private val _s23FrameFlow = MutableSharedFlow<Frame>(replay = 0, extraBufferCapacity = 10)
    val s23FrameFlow: SharedFlow<Frame> = _s23FrameFlow.asSharedFlow()

    private val _oneplusFrameFlow = MutableSharedFlow<Frame>(replay = 0, extraBufferCapacity = 10)
    val oneplusFrameFlow: SharedFlow<Frame> = _oneplusFrameFlow.asSharedFlow()

    private var s23Source: MJPEGSource? = null
    private var oneplusSource: CameraXSource? = null

    private var s23Job: Job? = null
    private var oneplusJob: Job? = null

    @Volatile
    var activeMode: CameraSourceType = CameraSourceType.DUAL_CAMERA
        private set

    /**
     * Starts the camera capture feeds based on the configured mode and stream parameters.
     */
    fun start(
        mode: CameraSourceType,
        streamUrl: String,
        serverHost: String,
        serverPort: Int
    ) {
        stop() // Reset previous instances
        activeMode = mode
        Log.i(TAG, "Starting CameraSourceManager in mode: $mode")

        scope.launch {
            val resolvedMode = if (mode == CameraSourceType.AUTO_DETECT) {
                if (pingStreamHost(streamUrl)) {
                    Log.i(TAG, "Auto-detect: Samsung stream is online. Selecting SAMSUNG_S23.")
                    CameraSourceType.SAMSUNG_S23
                } else {
                    Log.w(TAG, "Auto-detect: Samsung stream is offline. Falling back to ONEPLUS_CAMERA.")
                    CameraSourceType.ONEPLUS_CAMERA
                }
            } else {
                mode
            }

            when (resolvedMode) {
                CameraSourceType.SAMSUNG_S23 -> {
                    startS23Stream(streamUrl)
                }
                CameraSourceType.ONEPLUS_CAMERA -> {
                    startOnePlusCamera()
                }
                CameraSourceType.DUAL_CAMERA -> {
                    startS23Stream(streamUrl)
                    startOnePlusCamera()
                }
                else -> {}
            }
        }
    }

    /**
     * Stops all active camera streams and releases hardware bindings.
     */
    fun stop() {
        Log.i(TAG, "Stopping all camera sources...")
        s23Job?.cancel()
        s23Job = null
        oneplusJob?.cancel()
        oneplusJob = null

        s23Source?.stop()
        s23Source = null
        
        oneplusSource?.stop()
        oneplusSource = null
    }

    private fun startS23Stream(url: String) {
        val source = MJPEGSource(url)
        s23Source = source
        s23Job = scope.launch {
            launch {
                source.frameFlow.collect { frame ->
                    _s23FrameFlow.emit(frame)
                }
            }
            try {
                source.start()
            } catch (e: Exception) {
                Log.e(TAG, "Error in S23 stream source: ${e.message}")
            }
        }
    }

    private fun startOnePlusCamera() {
        val source = CameraXSource(context, lifecycleOwner)
        oneplusSource = source
        oneplusJob = scope.launch {
            launch {
                source.frameFlow.collect { frame ->
                    _oneplusFrameFlow.emit(frame)
                }
            }
            try {
                source.start()
            } catch (e: Exception) {
                Log.e(TAG, "Error in OnePlus CameraX source: ${e.message}")
            }
        }
    }

    /**
     * Pings the host of the stream URL to see if it is online (timeout 1.5 seconds).
     */
    private suspend fun pingStreamHost(urlStr: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val uri = URI(urlStr)
            val host = uri.host ?: return@withContext false
            val port = if (uri.port != -1) uri.port else 80
            
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 1500)
                return@withContext true
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed connection probe to stream host: ${e.message}")
            return@withContext false
        }
    }

    companion object {
        private const val TAG = "CameraSourceManager"
    }
}
