package com.oneplus.aicamera.communication.receiver

import android.content.Context
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.oneplus.aicamera.models.Frame
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Concrete implementation of [VideoSource] utilizing Android's CameraX API.
 * Captures live frames from the OnePlus back camera, converts them to OpenCV BGR Mats,
 * handles rotation, and emits them.
 */
class CameraXSource(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner
) : VideoSource {

    private val _frameFlow = MutableSharedFlow<Frame>(replay = 0, extraBufferCapacity = 8)
    override val frameFlow: SharedFlow<Frame> = _frameFlow.asSharedFlow()

    @Volatile
    private var _isStreaming = false
    override val isStreaming: Boolean get() = _isStreaming

    private var cameraProvider: ProcessCameraProvider? = null
    private var frameCounter = 0L

    override suspend fun start() {
        if (_isStreaming) return
        _isStreaming = true
        frameCounter = 0L
        Log.i(TAG, "Starting local CameraX stream...")

        withContext(Dispatchers.Main) {
            try {
                // Obtain Camera Provider asynchronously
                val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
                cameraProvider = suspendCancellableCoroutine { continuation ->
                    cameraProviderFuture.addListener({
                        try {
                            continuation.resume(cameraProviderFuture.get())
                        } catch (e: Exception) {
                            continuation.resumeWithException(e)
                        }
                    }, ContextCompat.getMainExecutor(context))
                }

                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                // Configure ImageAnalysis for optimal real-time processing
                val imageAnalysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(1280, 720))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                    .build()

                imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(context)) { imageProxy ->
                    try {
                        if (_isStreaming) {
                            val mat = yuvToBgr(imageProxy)
                            if (mat != null) {
                                frameCounter++
                                val frame = Frame(
                                    source = "OnePlus_15",
                                    frameNumber = frameCounter,
                                    timestamp = System.currentTimeMillis(),
                                    mat = mat
                                )
                                _frameFlow.tryEmit(frame)
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Exception during local camera frame analyze: ${e.message}", e)
                    } finally {
                        imageProxy.close()
                    }
                }

                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    imageAnalysis
                )
                Log.i(TAG, "CameraX successfully bound to lifecycle.")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start CameraX: ${e.message}", e)
                _isStreaming = false
            }
        }
    }

    override fun stop() {
        _isStreaming = false
        ContextCompat.getMainExecutor(context).execute {
            try {
                cameraProvider?.unbindAll()
                cameraProvider = null
            } catch (e: Exception) {
                Log.e(TAG, "Error unbinding CameraX: ${e.message}")
            }
        }
        Log.i(TAG, "CameraX streaming stopped.")
    }

    /**
     * Converts YUV_420_888 ImageProxy to BGR OpenCV Mat, correcting camera sensor rotation.
     */
    private fun yuvToBgr(image: ImageProxy): Mat? {
        val width = image.width
        val height = image.height

        val nv21Bytes = yuv420ToNv21(image) ?: return null

        // NV21 height is height * 1.5
        val yuvMat = Mat((height * 1.5).toInt(), width, CvType.CV_8UC1)
        yuvMat.put(0, 0, nv21Bytes)

        val bgrMat = Mat()
        Imgproc.cvtColor(yuvMat, bgrMat, Imgproc.COLOR_YUV2BGR_NV21)
        yuvMat.release()

        // Correct image orientation based on device sensor rotation
        val rotationDegrees = image.imageInfo.rotationDegrees
        if (rotationDegrees != 0) {
            val rotatedMat = Mat()
            when (rotationDegrees) {
                90 -> Core.rotate(bgrMat, rotatedMat, Core.ROTATE_90_CLOCKWISE)
                180 -> Core.rotate(bgrMat, rotatedMat, Core.ROTATE_180)
                270 -> Core.rotate(bgrMat, rotatedMat, Core.ROTATE_90_COUNTERCLOCKWISE)
                else -> bgrMat.copyTo(rotatedMat)
            }
            bgrMat.release()
            return rotatedMat
        }

        return bgrMat
    }

    /**
     * Extracts planes from YUV_420_888 to build a contiguous NV21 byte array.
     */
    private fun yuv420ToNv21(image: ImageProxy): ByteArray? {
        try {
            val width = image.width
            val height = image.height
            val yPlane = image.planes[0]
            val uPlane = image.planes[1]
            val vPlane = image.planes[2]

            val yBuffer = yPlane.buffer
            val uBuffer = uPlane.buffer
            val vBuffer = vPlane.buffer

            val ySize = yBuffer.remaining()
            val uSize = uBuffer.remaining()
            val vSize = vBuffer.remaining()

            val nv21 = ByteArray(width * height * 3 / 2)

            // Copy Y channel
            yBuffer.get(nv21, 0, ySize)

            val vPixelStride = vPlane.pixelStride
            val uPixelStride = uPlane.pixelStride
            val vRowStride = vPlane.rowStride
            val uRowStride = uPlane.rowStride

            var pos = width * height
            val chromaWidth = width / 2
            val chromaHeight = height / 2

            val vRow = ByteArray(vRowStride)
            val uRow = ByteArray(uRowStride)

            for (row in 0 until chromaHeight) {
                vBuffer.position(row * vRowStride)
                val vRead = Math.min(vRowStride, vBuffer.remaining())
                vBuffer.get(vRow, 0, vRead)

                uBuffer.position(row * uRowStride)
                val uRead = Math.min(uRowStride, uBuffer.remaining())
                uBuffer.get(uRow, 0, uRead)

                for (col in 0 until chromaWidth) {
                    nv21[pos++] = vRow[col * vPixelStride]
                    nv21[pos++] = uRow[col * uPixelStride]
                }
            }
            return nv21
        } catch (e: Exception) {
            Log.e(TAG, "Error copying YUV planes to NV21: ${e.message}")
            return null
        }
    }

    companion object {
        private const val TAG = "CameraXSource"
    }
}
