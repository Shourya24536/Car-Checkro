package com.oneplus.aicamera.models

import org.opencv.core.Mat

/**
 * Represents a single frame captured or received from a stream source.
 * Wraps the OpenCV [Mat] object, originating source, and associated processing metadata.
 */
data class Frame(
    val source: String, // "Samsung_S23" or "OnePlus_15"
    val frameNumber: Long,
    val timestamp: Long,
    val mat: Mat
)
