package com.oneplus.aicamera.utils

import com.oneplus.aicamera.models.Frame
import java.util.ArrayDeque
import java.util.Deque

/**
 * Thread-safe sliding-window frame buffer holding a history of frames.
 * Evicts and recycles older frames when capacity is exceeded.
 */
class FrameBuffer(
    capacity: Int = 5,
    private val matPool: MatPool? = null
) {
    @Volatile
    var capacity: Int = capacity
        set(value) {
            field = value
            resize()
        }

    private val queue: Deque<Frame> = ArrayDeque(capacity)

    /**
     * Pushes a new frame into the buffer. Evicts the oldest frame if size exceeds capacity.
     */
    @Synchronized
    fun push(frame: Frame) {
        if (capacity <= 0) {
            recycleFrame(frame)
            return
        }

        while (queue.size >= capacity) {
            val evicted = queue.pollFirst()
            if (evicted != null) {
                recycleFrame(evicted)
            }
        }
        queue.addLast(frame)
    }

    /**
     * Returns the latest frame (newest added) or null if buffer is empty.
     */
    @Synchronized
    fun getLatest(): Frame? {
        return queue.peekLast()
    }

    /**
     * Retrieves a frame at a specific offset back from the latest frame.
     * @param offset 0 returns latest frame, 1 returns the previous frame, etc.
     */
    @Synchronized
    fun getPrevious(offset: Int): Frame? {
        if (offset < 0 || offset >= queue.size) return null
        val list = queue.toList()
        return list[list.size - 1 - offset]
    }

    /**
     * Returns a copy of all current frames in chronological order (oldest first).
     */
    @Synchronized
    fun getAllFrames(): List<Frame> {
        return queue.toList()
    }

    /**
     * Clears all frames from the buffer and releases their native memory.
     */
    @Synchronized
    fun clear() {
        while (queue.isNotEmpty()) {
            val frame = queue.pollFirst()
            if (frame != null) {
                recycleFrame(frame)
            }
        }
    }

    /**
     * Returns the current number of frames in the buffer.
     */
    @Synchronized
    fun size(): Int {
        return queue.size
    }

    @Synchronized
    private fun resize() {
        while (queue.size > capacity) {
            val evicted = queue.pollFirst()
            if (evicted != null) {
                recycleFrame(evicted)
            }
        }
    }

    private fun recycleFrame(frame: Frame) {
        if (matPool != null) {
            matPool.recycle(frame.mat)
        } else {
            frame.mat.release()
        }
    }
}
