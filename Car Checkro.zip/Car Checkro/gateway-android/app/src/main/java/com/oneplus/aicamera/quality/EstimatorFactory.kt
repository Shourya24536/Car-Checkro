package com.oneplus.aicamera.quality

/**
 * Factory class to instantiate the active frame quality estimator implementation.
 */
object EstimatorFactory {

    /**
     * Resolves and returns the desired [FrameQualityEstimator] based on application settings.
     */
    fun create(
        useAiMode: Boolean,
        ruleConfig: EstimatorConfig = EstimatorConfig()
    ): FrameQualityEstimator {
        return if (useAiMode) {
            AIEstimator()
        } else {
            RuleBasedEstimator(ruleConfig)
        }
    }
}
