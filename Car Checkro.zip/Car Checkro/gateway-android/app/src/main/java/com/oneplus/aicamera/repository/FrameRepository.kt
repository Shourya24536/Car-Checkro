package com.oneplus.aicamera.repository

import android.util.Log
import com.oneplus.aicamera.communication.sender.UnoSender
import com.oneplus.aicamera.models.FrameScore
import com.oneplus.aicamera.utils.MatPool
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.opencv.core.Mat

/**
 * Task structure holding frame details for the background upload queue.
 */
data class UploadTask(
    val source: String,
    val mat: Mat,
    val score: FrameScore
)

/**
 * Repository in charge of selected frame storage, queue management, and upload dispatch.
 * Does not perform any CV operations. Tracks upload statistics for dashboards.
 */
class FrameRepository(
    private val unoSender: UnoSender,
    private val matPool: MatPool
) {

    private val scope = CoroutineScope(Dispatchers.IO)
    
    // Bounded channel to buffer frame uploads (max 10 items in queue to prevent OOM)
    private val uploadChannel = Channel<UploadTask>(capacity = 10)

    // Configurable JPEG quality (updated from ViewModel settings)
    @Volatile
    var jpegQuality: Int = 85

    // Statistics flow for the UI Dashboard
    private val _uploadQueueSize = MutableStateFlow(0)
    val uploadQueueSize: StateFlow<Int> = _uploadQueueSize.asStateFlow()

    private val _lastUploadTimeMs = MutableStateFlow(0L)
    val lastUploadTimeMs: StateFlow<Long> = _lastUploadTimeMs.asStateFlow()

    private val _networkStatus = MutableStateFlow("Idle")
    val networkStatus: StateFlow<String> = _networkStatus.asStateFlow()

    private val _totalAccepted = MutableStateFlow(0)
    val totalAccepted: StateFlow<Int> = _totalAccepted.asStateFlow()

    private val _totalFailedUploads = MutableStateFlow(0)
    val totalFailedUploads: StateFlow<Int> = _totalFailedUploads.asStateFlow()

    init {
        startUploadDispatcher()
    }

    /**
     * Enqueues an accepted frame for upload.
     * The Mat is copied into a separate pooled buffer so the pipeline can continue immediately.
     */
    fun enqueueUpload(source: String, mat: Mat, score: FrameScore) {
        // Obtain a Mat from pool and copy content to safely pass to background upload task
        val uploadMat = matPool.obtain()
        mat.copyTo(uploadMat)

        val task = UploadTask(source, uploadMat, score)
        val success = uploadChannel.trySend(task).isSuccess
        if (success) {
            _uploadQueueSize.value = _uploadQueueSize.value + 1
        } else {
            // Buffer full: drop frame, release Mat back to pool to avoid OOM
            Log.w(TAG, "Upload queue full. Dropped frame #${score.frameNumber} from source: $source to prevent memory leaks.")
            matPool.recycle(uploadMat)
        }
    }

    /**
     * Updates the server config on the sender client.
     */
    fun updateServerConfig(host: String, port: Int) {
        unoSender.updateServerAddress(host, port)
    }

    private fun startUploadDispatcher() {
        scope.launch {
            for (task in uploadChannel) {
                val source = task.source
                val mat = task.mat
                val score = task.score
                
                _networkStatus.value = "Uploading $source Frame #${score.frameNumber}"
                val uploadStart = System.currentTimeMillis()
                
                // Execute upload sequentially using the thread-safe single worker flow
                val result = unoSender.sendFrame(source, mat, score, jpegQuality)
                
                val uploadDuration = System.currentTimeMillis() - uploadStart
                _lastUploadTimeMs.value = uploadDuration
                _uploadQueueSize.value = (_uploadQueueSize.value - 1).coerceAtLeast(0)

                if (result.first) {
                    _networkStatus.value = "Success: ${result.second}"
                    _totalAccepted.value = _totalAccepted.value + 1
                    Log.d(TAG, "Successfully uploaded $source frame #${score.frameNumber} in ${uploadDuration}ms")
                } else {
                    _networkStatus.value = "Failed: ${result.second}"
                    _totalFailedUploads.value = _totalFailedUploads.value + 1
                    Log.e(TAG, "Failed uploading $source frame #${score.frameNumber}: ${result.second}")
                }

                // Recycle the frame's copied Mat
                matPool.recycle(mat)
            }
        }
    }

    companion object {
        private const val TAG = "FrameRepository"
    }
}
