package com.oneplus.aicamera.communication.receiver

import android.util.Log
import com.oneplus.aicamera.models.Frame
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.opencv.core.Mat
import org.opencv.core.MatOfByte
import org.opencv.imgcodecs.Imgcodecs
import java.io.BufferedInputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

/**
 * Concrete implementation of [VideoSource] that decodes an MJPEG HTTP live stream
 * (e.g., from an IP Webcam app on the Samsung S23).
 */
class MJPEGSource(
    private val streamUrl: String,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(1, TimeUnit.HOURS) // Long-lived stream connection
        .build()
) : VideoSource {

    private val _frameFlow = MutableSharedFlow<Frame>(replay = 0, extraBufferCapacity = 8)
    override val frameFlow: SharedFlow<Frame> = _frameFlow.asSharedFlow()

    @Volatile
    private var _isStreaming = false
    override val isStreaming: Boolean get() = _isStreaming

    private var frameCounter = 0L

    override suspend fun start() {
        if (_isStreaming) return
        _isStreaming = true
        frameCounter = 0L
        Log.d(TAG, "Starting MJPEG stream from: $streamUrl")

        withContext(Dispatchers.IO) {
            try {
                val request = Request.Builder()
                    .url(streamUrl)
                    .addHeader("Accept", "multipart/x-mixed-replace, */*")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        Log.e(TAG, "Failed to connect: HTTP status ${response.code}")
                        _isStreaming = false
                        return@withContext
                    }

                    val bodyStream = response.body?.byteStream()
                    if (bodyStream == null) {
                        Log.e(TAG, "Response body stream is null")
                        _isStreaming = false
                        return@withContext
                    }

                    parseAndDecodeStream(bodyStream)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error while streaming: ${e.message}", e)
            } finally {
                _isStreaming = false
                Log.d(TAG, "MJPEG streaming stopped.")
            }
        }
    }

    override fun stop() {
        _isStreaming = false
    }

    /**
     * Efficiently reads the incoming stream byte-by-byte (using BufferedInputStream)
     * to locate the SOI (Start Of Image: 0xFFD8) and EOI (End Of Image: 0xFFD9) markers.
     */
    private suspend fun parseAndDecodeStream(inputStream: InputStream) {
        val bufferedStream = BufferedInputStream(inputStream)
        // Pre-allocate buffer for JPEG image bytes (typical 1080p JPEG is < 300KB)
        val jpegBuffer = ByteArray(1024 * 1024)
        var bufferLength = 0
        
        var lastByte = 0
        var inFrame = false

        while (_isStreaming) {
            val byteVal = bufferedStream.read()
            if (byteVal == -1) {
                Log.d(TAG, "Stream reached End-Of-File (EOF)")
                break
            }

            if (inFrame) {
                if (bufferLength < jpegBuffer.size) {
                    jpegBuffer[bufferLength++] = byteVal.toByte()
                } else {
                    // Buffer overflow protection: reset
                    Log.w(TAG, "JPEG buffer overflow, frame discarded")
                    inFrame = false
                    bufferLength = 0
                }

                // Check for JPEG EOI (0xFF 0xD9)
                if (lastByte == 0xFF && byteVal == 0xD9) {
                    // Extract frame bytes and process
                    val frameBytes = ByteArray(bufferLength)
                    System.arraycopy(jpegBuffer, 0, frameBytes, 0, bufferLength)
                    
                    decodeAndEmit(frameBytes)
                    
                    inFrame = false
                    bufferLength = 0
                }
            } else {
                // Check for JPEG SOI (0xFF 0xD8)
                if (lastByte == 0xFF && byteVal == 0xD8) {
                    inFrame = true
                    jpegBuffer[0] = 0xFF.toByte()
                    jpegBuffer[1] = 0xD8.toByte()
                    bufferLength = 2
                }
            }
            lastByte = byteVal
        }
    }

    private suspend fun decodeAndEmit(jpegBytes: ByteArray) {
        try {
            // Convert byte array to MatOfByte
            val matOfByte = MatOfByte(*jpegBytes)
            
            // Decode image using OpenCV's native C++ implementation
            val mat = Imgcodecs.imdecode(matOfByte, Imgcodecs.IMREAD_COLOR)
            matOfByte.release() // Immediate native deallocation

            if (mat != null && !mat.empty()) {
                frameCounter++
                val frame = Frame(
                    source = "Samsung_S23",
                    frameNumber = frameCounter,
                    timestamp = System.currentTimeMillis(),
                    mat = mat
                )
                _frameFlow.emit(frame)
            } else {
                mat?.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed decoding JPEG payload to OpenCV Mat: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "MJPEGSource"
    }
}
