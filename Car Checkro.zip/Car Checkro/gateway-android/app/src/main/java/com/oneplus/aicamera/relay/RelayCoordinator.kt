package com.oneplus.aicamera.relay

import android.util.Log
import com.oneplus.aicamera.models.FrameScore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.opencv.core.Mat

/**
 * Thin coordinator that owns the [MjpegRelayServer] and exposes status
 * to the UI.  The ViewModel creates one instance of this class and calls
 * [pushFrame] whenever the processing pipeline accepts a frame.
 *
 * The relay server lifecycle mirrors the ViewModel's lifecycle:
 *   init {}           → start()
 *   onCleared()       → stop()
 */
class RelayCoordinator(private val relayPort: Int = 8090) {

    private val server = MjpegRelayServer(port = relayPort)

    private val _relayStatus = MutableStateFlow("Stopped")
    val relayStatus: StateFlow<String> = _relayStatus.asStateFlow()

    private val _connectedClients = MutableStateFlow(0)
    val connectedClients: StateFlow<Int> = _connectedClients.asStateFlow()

    private val _totalRelayed = MutableStateFlow(0)
    val totalRelayed: StateFlow<Int> = _totalRelayed.asStateFlow()

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    fun start() {
        server.start()
        _relayStatus.value = "Streaming on :$relayPort"
        Log.i(TAG, "MJPEG relay started on port $relayPort")
    }

    fun stop() {
        server.stop()
        _relayStatus.value = "Stopped"
        Log.i(TAG, "MJPEG relay stopped")
    }

    // -------------------------------------------------------------------------
    // Frame routing
    // -------------------------------------------------------------------------

    /**
     * Called by the pipeline for every **accepted** frame.
     * Forwards the frame to the MJPEG relay so the UNO-Q can consume it
     * via cv::VideoCapture.
     *
     * @param mat         The enhanced, accepted OpenCV [Mat] (BGR).
     * @param score       Frame quality score (used only for logging).
     * @param jpegQuality JPEG quality for the relay stream (1-100).
     */
    fun pushFrame(mat: Mat, score: FrameScore, jpegQuality: Int = 85) {
        server.pushFrame(mat, jpegQuality)

        _connectedClients.value = server.connectedClientCount
        _totalRelayed.value = _totalRelayed.value + 1

        Log.v(TAG, "Relayed frame #${score.frameNumber} to ${server.connectedClientCount} UNO-Q client(s)")
    }

    val isRunning: Boolean get() = server.isRunning
    val streamUrl: String get() = server.streamUrl

    companion object {
        private const val TAG = "RelayCoordinator"
    }
}
