package com.oneplus.aicamera.utils

import android.util.Log
import org.opencv.core.Mat
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * A thread-safe pool of OpenCV Mat objects.
 * Helps prevent memory churning and native memory leaks by reusing Mat allocations.
 */
class MatPool(private val maxPoolSize: Int = 15) {

    private val pool = ConcurrentLinkedQueue<Mat>()

    /**
     * Obtains a Mat from the pool, or allocates a new one if the pool is empty.
     * If retrieved from the pool, [Mat.release] is called to clear the image content
     * without deallocating the underlying native structure.
     */
    fun obtain(): Mat {
        val mat = pool.poll()
        if (mat != null) {
            mat.release()
            return mat
        }
        return Mat()
    }

    /**
     * Obtains a Mat and structures it to match specified dimensions and type.
     */
    fun obtain(rows: Int, cols: Int, type: Int): Mat {
        val mat = obtain()
        mat.create(rows, cols, type)
        return mat
    }

    /**
     * Recycles a Mat back into the pool. 
     * Once recycled, the caller must release their reference and not perform operations on it.
     */
    fun recycle(mat: Mat?) {
        if (mat == null) return
        if (pool.size < maxPoolSize) {
            pool.offer(mat)
        } else {
            mat.release() // Pool limit reached, release native resources immediately
        }
    }

    /**
     * Clears all pooled Mats and releases their native allocations.
     */
    fun clear() {
        while (pool.isNotEmpty()) {
            pool.poll()?.release()
        }
    }

    companion object {
        private const val TAG = "MatPool"
    }
}
