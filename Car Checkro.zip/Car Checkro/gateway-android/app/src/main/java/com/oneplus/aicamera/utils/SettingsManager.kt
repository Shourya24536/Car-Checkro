package com.oneplus.aicamera.utils

import android.content.Context
import android.content.SharedPreferences
import com.oneplus.aicamera.communication.receiver.CameraSourceType
import com.oneplus.aicamera.enhancement.EnhancementConfig
import com.oneplus.aicamera.pipeline.PipelineConfig
import com.oneplus.aicamera.quality.ExposureConfig
import com.oneplus.aicamera.reflection.ReflectionConfig

/**
 * Handles persistent storage of configurations and thresholds for the AI Camera Gateway.
 */
class SettingsManager(context: Context) {
    
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var blurThreshold: Double
        get() = prefs.getFloat(KEY_BLUR_THRESH, 80.0f).toDouble()
        set(value) = prefs.edit().putFloat(KEY_BLUR_THRESH, value.toFloat()).apply()

    var motionThreshold: Double
        get() = prefs.getFloat(KEY_MOTION_THRESH, 2.0f).toDouble()
        set(value) = prefs.edit().putFloat(KEY_MOTION_THRESH, value.toFloat()).apply()

    var jpegQuality: Int
        get() = prefs.getInt(KEY_JPEG_QUALITY, 85)
        set(value) = prefs.edit().putInt(KEY_JPEG_QUALITY, value).apply()

    var serverHost: String
        get() = prefs.getString(KEY_SERVER_HOST, "192.168.1.5") ?: "192.168.1.5"
        set(value) = prefs.edit().putString(KEY_SERVER_HOST, value).apply()

    var serverPort: Int
        get() = prefs.getInt(KEY_SERVER_PORT, 8000)
        set(value) = prefs.edit().putInt(KEY_SERVER_PORT, value).apply()

    /**
     * Port the OnePlus device exposes for the filtered MJPEG relay stream.
     * The UNO-Q dent_detector points cv::VideoCapture at
     * http://<OnePlus-IP>:<mjpegRelayPort>/stream
     */
    var mjpegRelayPort: Int
        get() = prefs.getInt(KEY_RELAY_PORT, 8090)
        set(value) = prefs.edit().putInt(KEY_RELAY_PORT, value).apply()

    var streamUrl: String
        get() = prefs.getString(KEY_STREAM_URL, "http://192.168.1.100:8080/video") ?: "http://192.168.1.100:8080/video"
        set(value) = prefs.edit().putString(KEY_STREAM_URL, value).apply()

    var useAiEstimator: Boolean
        get() = prefs.getBoolean(KEY_USE_AI, false)
        set(value) = prefs.edit().putBoolean(KEY_USE_AI, value).apply()

    var enableEnhancement: Boolean
        get() = prefs.getBoolean(KEY_ENABLE_ENHANCEMENT, true)
        set(value) = prefs.edit().putBoolean(KEY_ENABLE_ENHANCEMENT, value).apply()

    var maxReflectionPercent: Double
        get() = prefs.getFloat(KEY_REFL_PERCENT, 5.0f).toDouble()
        set(value) = prefs.edit().putFloat(KEY_REFL_PERCENT, value.toFloat()).apply()

    var maxReflectionCount: Int
        get() = prefs.getInt(KEY_REFL_COUNT, 15)
        set(value) = prefs.edit().putInt(KEY_REFL_COUNT, value).apply()

    var maxLargestBlobArea: Double
        get() = prefs.getFloat(KEY_REFL_BLOB, 2000.0f).toDouble()
        set(value) = prefs.edit().putFloat(KEY_REFL_BLOB, value.toFloat()).apply()

    var cameraSource: Int
        get() = prefs.getInt(KEY_CAMERA_SOURCE, CameraSourceType.DUAL_CAMERA.ordinal)
        set(value) = prefs.edit().putInt(KEY_CAMERA_SOURCE, value).apply()

    var gamma: Double
        get() = prefs.getFloat(KEY_GAMMA, 1.0f).toDouble()
        set(value) = prefs.edit().putFloat(KEY_GAMMA, value.toFloat()).apply()

    /**
     * Translates stored settings into a consolidated [PipelineConfig] wrapper.
     */
    fun getPipelineConfig(): PipelineConfig {
        return PipelineConfig(
            blurThreshold = blurThreshold,
            motionThreshold = motionThreshold,
            isEnhancementEnabled = enableEnhancement,
            enhancementConfig = EnhancementConfig(
                isWhiteBalanceEnabled = true,
                isDenoiseEnabled = true,
                isClaheEnabled = true,
                isSharpenEnabled = true,
                sharpenAmount = 0.5f,
                gamma = gamma
            ),
            exposureConfig = ExposureConfig(
                minBrightness = 40.0,
                maxBrightness = 220.0,
                minDynamicRange = 50.0
            ),
            reflectionConfig = ReflectionConfig(
                maxSaturatedPixelPercent = maxReflectionPercent,
                maxReflectionCount = maxReflectionCount,
                maxLargestBlobArea = maxLargestBlobArea
            )
        )
    }

    companion object {
        private const val PREFS_NAME = "gateway_settings"
        private const val KEY_BLUR_THRESH = "blur_threshold"
        private const val KEY_MOTION_THRESH = "motion_threshold"
        private const val KEY_JPEG_QUALITY = "jpeg_quality"
        private const val KEY_SERVER_HOST = "server_host"
        private const val KEY_SERVER_PORT = "server_port"
        private const val KEY_RELAY_PORT = "mjpeg_relay_port"
        private const val KEY_STREAM_URL = "stream_url"
        private const val KEY_USE_AI = "use_ai"
        private const val KEY_ENABLE_ENHANCEMENT = "enable_enhancement"
        private const val KEY_REFL_PERCENT = "refl_percent"
        private const val KEY_REFL_COUNT = "refl_count"
        private const val KEY_REFL_BLOB = "refl_blob"
        private const val KEY_CAMERA_SOURCE = "camera_source_mode"
        private const val KEY_GAMMA = "gamma_multiplier"
    }
}
