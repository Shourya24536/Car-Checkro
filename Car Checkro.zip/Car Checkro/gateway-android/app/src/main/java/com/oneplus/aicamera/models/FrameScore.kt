package com.oneplus.aicamera.models

/**
 * Data class holding the results of frame analysis, quality calculations,
 * and processing latency diagnostics.
 */
data class FrameScore(
    val quality: Int,           // Final weighted quality score (0 to 100)
    val blur: Double,           // Blur score (Laplacian variance)
    val motion: Double,         // Motion score (%)
    val reflection: Double,     // Saturated pixel percent (%)
    val brightness: Double,     // Average brightness (0 to 255)
    val timestamp: Long,        // Epoch timestamp of creation
    val frameNumber: Long,      // Sequence frame number
    val processingTime: Long    // Total pipeline processing duration in milliseconds
)
