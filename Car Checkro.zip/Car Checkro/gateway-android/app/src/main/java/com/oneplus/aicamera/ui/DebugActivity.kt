package com.oneplus.aicamera.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.oneplus.aicamera.communication.receiver.CameraSourceType
import com.oneplus.aicamera.databinding.ActivityDebugBinding
import com.oneplus.aicamera.utils.SettingsManager
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Dedicated debug activity displaying format specs, OpenCV settings,
 * channel averages, and custom-rendered live grayscale histogram curves.
 */
class DebugActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDebugBinding
    private lateinit var settingsManager: SettingsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDebugBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settingsManager = SettingsManager(this)

        setupToolbar()
        loadStaticProperties()
        observeTelemetry()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    private fun loadStaticProperties() {
        val mode = CameraSourceType.values()[settingsManager.cameraSource]
        binding.tvDebugSource.text = mode.name
        
        binding.tvDebugClaheStatus.text = if (settingsManager.enableEnhancement) {
            "Enabled (ClipLimit=2.0, Tile=8x8)"
        } else {
            "Disabled"
        }

        binding.tvDebugWbStatus.text = if (settingsManager.enableEnhancement) {
            "Enabled (GrayWorld Bounded [0.7, 1.3])"
        } else {
            "Disabled"
        }
    }

    private fun observeTelemetry() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                
                // 1. Collect average RGB channel values
                launch {
                    DebugTelemetry.activeS23AvgRgb.collectLatest { s23Rgb ->
                        val opRgb = DebugTelemetry.activeOneplusAvgRgb.value
                        binding.tvDebugAvgRgb.text = String.format(
                            "S23: R=%.1f  G=%.1f  B=%.1f\nOP15: R=%.1f  G=%.1f  B=%.1f",
                            s23Rgb[0], s23Rgb[1], s23Rgb[2],
                            opRgb[0], opRgb[1], opRgb[2]
                        )
                    }
                }

                // 2. Render S23 grayscale histogram chart
                launch {
                    DebugTelemetry.s23Histogram.collectLatest { histArray ->
                        val bmp = renderHistogram(histArray, "#4CAF50") // Green curve
                        binding.ivS23Histogram.setImageBitmap(bmp)
                    }
                }

                // 3. Render OnePlus 15 grayscale histogram chart
                launch {
                    DebugTelemetry.oneplusHistogram.collectLatest { histArray ->
                        val bmp = renderHistogram(histArray, "#00BCD4") // Cyan curve
                        binding.ivOneplusHistogram.setImageBitmap(bmp)
                    }
                }
            }
        }
    }

    /**
     * Renders a beautiful, anti-aliased area chart representing the 256-bin grayscale histogram.
     */
    private fun renderHistogram(histData: FloatArray, hexColor: String): Bitmap {
        val width = 512
        val height = 200
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.parseColor("#1E1E1E")) // Dark background

        if (histData.isEmpty()) return bmp

        val maxVal = histData.maxOrNull() ?: 1.0f
        val stepX = width.toFloat() / 256f

        val strokePaint = Paint().apply {
            color = Color.parseColor(hexColor)
            style = Paint.Style.STROKE
            strokeWidth = 3f
            isAntiAlias = true
        }

        val fillPaint = Paint().apply {
            color = Color.parseColor(hexColor)
            alpha = 25 // ~10% opacity transparent fill
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val path = Path()
        path.moveTo(0f, height.toFloat())

        for (i in 0 until 256) {
            val normalizedVal = if (maxVal > 0) histData[i] / maxVal else 0f
            // Calculate height keeping 10% margin at the top
            val y = height - (normalizedVal * height * 0.9f)
            val x = i * stepX
            path.lineTo(x, y)
        }
        path.lineTo(width.toFloat(), height.toFloat())
        path.close()

        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, strokePaint)

        return bmp
    }
}
