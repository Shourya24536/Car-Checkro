package com.oneplus.aicamera.ui

import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Singleton repository to share live image processing telemetry values
 * (average channel intensities, gray histograms) between the background pipelines
 * and the telemetry debug screen.
 */
object DebugTelemetry {
    val activeS23AvgRgb = MutableStateFlow(doubleArrayOf(0.0, 0.0, 0.0))
    val activeOneplusAvgRgb = MutableStateFlow(doubleArrayOf(0.0, 0.0, 0.0))
    
    val s23Histogram = MutableStateFlow(FloatArray(256))
    val oneplusHistogram = MutableStateFlow(FloatArray(256))
}
