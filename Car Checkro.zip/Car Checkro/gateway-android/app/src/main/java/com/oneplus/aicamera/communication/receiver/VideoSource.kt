package com.oneplus.aicamera.communication.receiver

import com.oneplus.aicamera.models.Frame
import kotlinx.coroutines.flow.SharedFlow

/**
 * Common interface for video sources (MJPEG, RTSP, local CameraX).
 * Exposes a hot flow of decoded video frames.
 */
interface VideoSource {
    /**
     * Hot stream of incoming frames.
     */
    val frameFlow: SharedFlow<Frame>

    /**
     * Connection status check.
     */
    val isStreaming: Boolean

    /**
     * Starts receiving and decoding frames from the source.
     */
    suspend fun start()

    /**
     * Stops the video source stream and releases network resources.
     */
    fun stop()
}
