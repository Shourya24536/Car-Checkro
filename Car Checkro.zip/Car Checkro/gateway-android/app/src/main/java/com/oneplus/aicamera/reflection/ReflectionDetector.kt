package com.oneplus.aicamera.reflection

import com.oneplus.aicamera.utils.MatPool
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.imgproc.Imgproc
import java.util.ArrayList

/**
 * Configuration parameters for reflection and glare validation.
 */
data class ReflectionConfig(
    val maxSaturatedPixelPercent: Double = 5.0,  // Max % of frame allowed to be white glare
    val maxReflectionCount: Int = 15,            // Max count of glare spots
    val maxLargestBlobArea: Double = 2000.0,     // Max size of a single glare spot
    val saturationThreshold: Double = 250.0      // Pixel value considered saturated
)

/**
 * Encapsulates the results of reflection and glare estimation.
 */
data class ReflectionResult(
    val saturatedPixelPercent: Double,
    val reflectionCount: Int,
    val largestBlobArea: Double
)

/**
 * Detects specular reflections and glare on metallic surfaces (e.g., cans) using OpenCV contour analysis.
 */
class ReflectionDetector(private val matPool: MatPool) {

    /**
     * Estimates glare metrics by finding clusters of saturated pixels.
     */
    fun analyze(src: Mat, config: ReflectionConfig): ReflectionResult {
        if (src.empty()) {
            return ReflectionResult(0.0, 0, 0.0)
        }

        val gray = matPool.obtain()
        val binaryThresh = matPool.obtain()
        val contours = ArrayList<MatOfPoint>()
        val hierarchy = Mat()

        try {
            // 1. Convert to grayscale
            if (src.channels() > 1) {
                Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY)
            } else {
                src.copyTo(gray)
            }

            // 2. Threshold to find saturated highlights (intensity > threshold)
            Imgproc.threshold(
                gray, 
                binaryThresh, 
                config.saturationThreshold, 
                255.0, 
                Imgproc.THRESH_BINARY
            )

            // 3. Saturated pixel percentage
            val totalPixels = binaryThresh.rows() * binaryThresh.cols().toDouble()
            val whitePixels = Core.countNonZero(binaryThresh)
            val saturatedPixelPercent = if (totalPixels > 0) {
                (whitePixels.toDouble() / totalPixels) * 100.0
            } else {
                0.0
            }

            // 4. Find contours of the glare regions
            Imgproc.findContours(
                binaryThresh, 
                contours, 
                hierarchy, 
                Imgproc.RETR_EXTERNAL, 
                Imgproc.CHAIN_APPROX_SIMPLE
            )

            val reflectionCount = contours.size
            var largestBlobArea = 0.0

            for (contour in contours) {
                val area = Imgproc.contourArea(contour)
                if (area > largestBlobArea) {
                    largestBlobArea = area
                }
            }

            return ReflectionResult(
                saturatedPixelPercent = saturatedPixelPercent,
                reflectionCount = reflectionCount,
                largestBlobArea = largestBlobArea
            )
        } catch (e: Exception) {
            return ReflectionResult(0.0, 0, 0.0)
        } finally {
            // Clean up OpenCV native memory to prevent leaks
            matPool.recycle(gray)
            matPool.recycle(binaryThresh)
            hierarchy.release()
            for (contour in contours) {
                contour.release()
            }
        }
    }

    /**
     * Checks if the frame is rejected due to excessive glare.
     */
    fun isAcceptable(result: ReflectionResult, config: ReflectionConfig): Boolean {
        return result.saturatedPixelPercent <= config.maxSaturatedPixelPercent &&
               result.reflectionCount <= config.maxReflectionCount &&
               result.largestBlobArea <= config.maxLargestBlobArea
    }
}
