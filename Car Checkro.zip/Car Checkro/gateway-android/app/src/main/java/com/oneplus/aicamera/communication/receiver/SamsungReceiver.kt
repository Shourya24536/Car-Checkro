package com.oneplus.aicamera.communication.receiver

import android.util.Log
import com.oneplus.aicamera.models.Frame
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

/**
 * Orchestrates connection to the Samsung S23 video feed.
 * Dynamically launches the active [VideoSource] in a Coroutine block.
 */
class SamsungReceiver {

    private val scope = CoroutineScope(Dispatchers.Default)
    private var activeSource: VideoSource? = null
    private var streamJob: Job? = null

    private val _compositeFrameFlow = MutableSharedFlow<Frame>(replay = 0, extraBufferCapacity = 8)
    /**
     * Aggregated hot flow of frames dispatched from the active source.
     */
    val frameFlow: SharedFlow<Frame> = _compositeFrameFlow.asSharedFlow()

    /**
     * Checks if a stream is currently connected and active.
     */
    val isStreaming: Boolean
        get() = activeSource?.isStreaming ?: false

    /**
     * Starts streaming from the provided [VideoSource].
     */
    fun start(source: VideoSource) {
        stop() // Reset previous source if active
        activeSource = source

        streamJob = scope.launch {
            // Forward frames from source flow to composite flow
            val forwardJob = launch {
                source.frameFlow.collect { frame ->
                    _compositeFrameFlow.emit(frame)
                }
            }

            try {
                source.start()
            } catch (e: Exception) {
                Log.e(TAG, "Exception running video source stream: ${e.message}", e)
            } finally {
                forwardJob.cancel()
            }
        }
    }

    /**
     * Stops the active stream connection and cleans up execution threads.
     */
    fun stop() {
        streamJob?.cancel()
        streamJob = null
        activeSource?.stop()
        activeSource = null
    }

    companion object {
        private const val TAG = "SamsungReceiver"
    }
}
