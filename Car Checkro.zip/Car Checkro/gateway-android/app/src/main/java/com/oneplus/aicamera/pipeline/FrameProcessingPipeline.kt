package com.oneplus.aicamera.pipeline

import android.util.Log
import com.oneplus.aicamera.blur.BlurDetector
import com.oneplus.aicamera.enhancement.EnhancementConfig
import com.oneplus.aicamera.enhancement.ImageEnhancer
import com.oneplus.aicamera.models.Frame
import com.oneplus.aicamera.models.FrameScore
import com.oneplus.aicamera.motion.MotionDetector
import com.oneplus.aicamera.quality.ExposureAnalyzer
import com.oneplus.aicamera.quality.ExposureConfig
import com.oneplus.aicamera.quality.FrameQualityEstimator
import com.oneplus.aicamera.reflection.ReflectionConfig
import com.oneplus.aicamera.reflection.ReflectionDetector
import com.oneplus.aicamera.utils.FrameBuffer
import com.oneplus.aicamera.utils.MatPool
import org.opencv.core.Mat

/**
 * Event callbacks for frame processing results, consumed by ViewModel/UI.
 */
interface PipelineListener {
    fun onFrameProcessed(
        originalFrame: Frame,
        enhancedMat: Mat,
        score: FrameScore,
        isAccepted: Boolean,
        rejectionReason: String?
    )
}

/**
 * Global configurations for pipeline thresholds.
 */
data class PipelineConfig(
    val blurThreshold: Double = 80.0,
    val motionThreshold: Double = 2.0,
    val minQualityScore: Int = 75,
    val isEnhancementEnabled: Boolean = true,
    val enhancementConfig: EnhancementConfig = EnhancementConfig(),
    val exposureConfig: ExposureConfig = ExposureConfig(),
    val reflectionConfig: ReflectionConfig = ReflectionConfig()
)

/**
 * Orchestrates the sequential processing of video frames.
 * Integrates image enhancement, blur/motion detection, exposure analysis,
 * reflection/glare profiling, scoring, and frame selection.
 */
class FrameProcessingPipeline(
    private val matPool: MatPool,
    private val frameBuffer: FrameBuffer,
    private val enhancer: ImageEnhancer,
    private val blurDetector: BlurDetector,
    private val motionDetector: MotionDetector,
    private val exposureAnalyzer: ExposureAnalyzer,
    private val reflectionDetector: ReflectionDetector,
    @Volatile var qualityEstimator: FrameQualityEstimator,
    @Volatile var config: PipelineConfig = PipelineConfig()
) {

    private var listener: PipelineListener? = null

    fun setListener(listener: PipelineListener?) {
        this.listener = listener
    }

    /**
     * Processes an incoming raw video frame.
     * Manages native memory boundaries strictly to prevent memory leaks.
     */
    fun process(rawFrame: Frame) {
        val startTime = System.currentTimeMillis()
        val enhancedMat = matPool.obtain()

        try {
            // 1. Image Enhancement (Conditional)
            if (config.isEnhancementEnabled) {
                enhancer.enhance(rawFrame.mat, enhancedMat, config.enhancementConfig)
            } else {
                rawFrame.mat.copyTo(enhancedMat)
            }

            // 2. Blur / Sharpness Detection
            val blurScore = blurDetector.calculateBlurScore(enhancedMat)

            // 3. Motion Detection (Compare against previous frame in rolling FrameBuffer)
            val prevFrame = frameBuffer.getLatest()
            val motionScore = if (prevFrame != null) {
                motionDetector.calculateMotion(enhancedMat, prevFrame.mat)
            } else {
                0.0
            }

            // 4. Exposure Analysis
            val exposureResult = exposureAnalyzer.analyze(enhancedMat)

            // 5. Reflection & Glare Analysis
            val reflectionResult = reflectionDetector.analyze(enhancedMat, config.reflectionConfig)

            // 6. Execution Latency Calculation
            val latencyMs = System.currentTimeMillis() - startTime

            // 7. Combined Quality Score Calculation
            val frameScore = qualityEstimator.estimate(
                frame = rawFrame,
                blur = blurScore,
                motion = motionScore,
                reflection = reflectionResult.saturatedPixelPercent,
                brightness = exposureResult.averageBrightness,
                processingTimeMs = latencyMs
            )

            // 8. Rejection Rules evaluation
            var isAccepted = true
            var rejectionReason: String? = null

            when {
                !blurDetector.isSharp(blurScore, config.blurThreshold) -> {
                    isAccepted = false
                    rejectionReason = "Blurry (score: ${blurScore.toInt()} < ${config.blurThreshold.toInt()})"
                }
                !motionDetector.isStable(motionScore, config.motionThreshold) -> {
                    isAccepted = false
                    rejectionReason = "Moving (score: ${String.format("%.2f", motionScore)}% > ${config.motionThreshold}%)"
                }
                !exposureAnalyzer.isAcceptable(
                    exposureResult.averageBrightness,
                    exposureResult.dynamicRange,
                    config.exposureConfig
                ) -> {
                    isAccepted = false
                    rejectionReason = "Bad Exposure (brightness: ${exposureResult.averageBrightness.toInt()}, dr: ${exposureResult.dynamicRange.toInt()})"
                }
                !reflectionDetector.isAcceptable(reflectionResult, config.reflectionConfig) -> {
                    isAccepted = false
                    rejectionReason = "Excessive Glare (saturated: ${String.format("%.2f", reflectionResult.saturatedPixelPercent)}%, size: ${reflectionResult.largestBlobArea.toInt()})"
                }
                frameScore.quality < config.minQualityScore -> {
                    isAccepted = false
                    rejectionReason = "Low Quality Score (${frameScore.quality} < ${config.minQualityScore})"
                }
            }

            // 9. If frame is stable and clean, push to rolling buffer for subsequent motion comparison
            if (isAccepted) {
                // Keep the frame in rolling buffer. Make sure to copy the enhanced frame Mat
                val bufferMat = matPool.obtain()
                enhancedMat.copyTo(bufferMat)
                val bufferFrame = Frame(rawFrame.source, rawFrame.frameNumber, rawFrame.timestamp, bufferMat)
                frameBuffer.push(bufferFrame)
            }

            // 10. Dispatch results to subscriber
            listener?.onFrameProcessed(rawFrame, enhancedMat, frameScore, isAccepted, rejectionReason)

        } catch (e: Exception) {
            Log.e(TAG, "Exception during pipeline frame execution: ${e.message}", e)
        } finally {
            // Free the enhancedMat returned from obtain()
            matPool.recycle(enhancedMat)
            // Relieve the rawFrame's native mat resources since it is consumed
            rawFrame.mat.release()
        }
    }

    companion object {
        private const val TAG = "FrameProcessingPipeline"
    }
}
