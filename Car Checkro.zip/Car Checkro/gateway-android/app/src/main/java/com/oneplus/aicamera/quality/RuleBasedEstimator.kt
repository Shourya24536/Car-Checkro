package com.oneplus.aicamera.quality

import com.oneplus.aicamera.models.Frame
import com.oneplus.aicamera.models.FrameScore
import kotlin.math.abs

/**
 * Weights and normalization bounds for rule-based quality evaluation.
 */
data class EstimatorConfig(
    val blurWeight: Float = 0.4f,
    val motionWeight: Float = 0.2f,
    val exposureWeight: Float = 0.2f,
    val reflectionWeight: Float = 0.2f,

    val blurOptimal: Double = 200.0,   // Blur scores >= 200 are considered fully sharp (100%)
    val blurMin: Double = 50.0,        // Blur scores <= 50 are considered fully blurry (0%)
    val motionMax: Double = 5.0,       // Motion % >= 5.0% is considered maximum motion (0%)
    val reflectionMax: Double = 5.0    // Reflection % >= 5.0% is considered maximum glare (0%)
)

/**
 * Rule-based implementation of [FrameQualityEstimator].
 * Scores frames by interpolating raw CV measurements against configured limits.
 */
class RuleBasedEstimator(
    private val config: EstimatorConfig = EstimatorConfig()
) : FrameQualityEstimator {

    override fun estimate(
        frame: Frame,
        blur: Double,
        motion: Double,
        reflection: Double,
        brightness: Double,
        processingTimeMs: Long
    ): FrameScore {
        // 1. Normalize Blur Score
        val normBlur = if (blur >= config.blurOptimal) {
            100.0
        } else if (blur <= config.blurMin) {
            0.0
        } else {
            ((blur - config.blurMin) / (config.blurOptimal - config.blurMin)) * 100.0
        }

        // 2. Normalize Motion Score
        val normMotion = if (motion >= config.motionMax) {
            0.0
        } else {
            (1.0 - (motion / config.motionMax)) * 100.0
        }

        // 3. Normalize Exposure (optimal brightness around 128.0)
        val dev = abs(brightness - 128.0)
        val normExposure = (1.0 - (dev / 100.0).coerceIn(0.0, 1.0)) * 100.0

        // 4. Normalize Reflection
        val normReflection = if (reflection >= config.reflectionMax) {
            0.0
        } else {
            (1.0 - (reflection / config.reflectionMax)) * 100.0
        }

        // Apply weights
        val weightedScore = (normBlur * config.blurWeight) +
                (normMotion * config.motionWeight) +
                (normExposure * config.exposureWeight) +
                (normReflection * config.reflectionWeight)

        return FrameScore(
            quality = weightedScore.toInt().coerceIn(0, 100),
            blur = blur,
            motion = motion,
            reflection = reflection,
            brightness = brightness,
            timestamp = frame.timestamp,
            frameNumber = frame.frameNumber,
            processingTime = processingTimeMs
        )
    }
}
