package com.oneplus.aicamera.quality

import com.oneplus.aicamera.models.Frame
import com.oneplus.aicamera.models.FrameScore

/**
 * Interface contract for evaluating the quality score of a video frame.
 */
interface FrameQualityEstimator {
    /**
     * Estimates the final quality score and returns a [FrameScore] details object.
     */
    fun estimate(
        frame: Frame,
        blur: Double,
        motion: Double,
        reflection: Double,
        brightness: Double,
        processingTimeMs: Long
    ): FrameScore
}
