package com.oneplus.aicamera.network

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

/**
 * API response structure returned by the Arduino UNO-Q / Dashboard server.
 */
data class UploadResponse(
    val success: Boolean,
    val message: String?
)

/**
 * Retrofit interface representing the upload service endpoint on the Arduino UNO-Q gateway.
 */
interface UnoqApiService {

    /**
     * Uploads an enhanced selected frame with its evaluation metadata.
     * The image is sent as a JPEG file part; metadata is sent as a JSON body part.
     */
    @Multipart
    @POST("upload")
    fun uploadFrame(
        @Part image: MultipartBody.Part,
        @Part("metadata") metadata: RequestBody
    ): Call<UploadResponse>
}
