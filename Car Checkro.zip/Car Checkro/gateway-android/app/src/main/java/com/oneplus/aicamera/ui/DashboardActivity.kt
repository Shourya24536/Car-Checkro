package com.oneplus.aicamera.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.oneplus.aicamera.R
import com.oneplus.aicamera.communication.receiver.CameraSourceType
import com.oneplus.aicamera.databinding.ActivityDashboardBinding
import com.oneplus.aicamera.diagnostics.DiagnosticsSnapshot
import com.oneplus.aicamera.models.FrameScore
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Main UI Dashboard presenting live dual camera previews, CV score indicators,
 * upload statistics, and Snapdragon SoC telemetry values.
 */
class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding
    private val viewModel: DashboardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize camera source manager with activity's lifecycle owner
        viewModel.initSourceManager(this)

        setupButtons()
        observeViewModel()
    }

    override fun onResume() {
        super.onResume()
        // Refresh configurations in case they were modified in SettingsActivity
        viewModel.refreshConfig()
    }

    private fun setupButtons() {
        binding.btnToggleStream.setOnClickListener {
            viewModel.toggleStream()
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnDebug.setOnClickListener {
            startActivity(Intent(this, DebugActivity::class.java))
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                // 1. Connection & Stream State
                launch {
                    viewModel.isStreaming.collectLatest { streaming ->
                        if (streaming) {
                            binding.btnToggleStream.text = "STOP GATEWAY FEED"
                            binding.btnToggleStream.setBackgroundColor(Color.RED)
                            
                            // Adjust layout visibility based on selected camera source
                            val activeMode = viewModel.getActiveCameraMode()
                            when (activeMode) {
                                CameraSourceType.SAMSUNG_S23 -> {
                                    binding.cardS23.visibility = View.VISIBLE
                                    binding.cardOneplus.visibility = View.GONE
                                    binding.tvS23LiveIndicator.text = "S23: LIVE"
                                    binding.tvS23LiveIndicator.setBackgroundResource(R.drawable.bg_indicator_green)
                                }
                                CameraSourceType.ONEPLUS_CAMERA -> {
                                    binding.cardS23.visibility = View.GONE
                                    binding.cardOneplus.visibility = View.VISIBLE
                                    binding.tvOneplusLiveIndicator.text = "OP15: LIVE"
                                    binding.tvOneplusLiveIndicator.setBackgroundResource(R.drawable.bg_indicator_green)
                                }
                                CameraSourceType.DUAL_CAMERA, CameraSourceType.AUTO_DETECT -> {
                                    binding.cardS23.visibility = View.VISIBLE
                                    binding.cardOneplus.visibility = View.VISIBLE
                                    binding.tvS23LiveIndicator.text = "S23: LIVE"
                                    binding.tvS23LiveIndicator.setBackgroundResource(R.drawable.bg_indicator_green)
                                    binding.tvOneplusLiveIndicator.text = "OP15: LIVE"
                                    binding.tvOneplusLiveIndicator.setBackgroundResource(R.drawable.bg_indicator_green)
                                }
                            }
                        } else {
                            binding.btnToggleStream.text = "START GATEWAY FEED"
                            binding.btnToggleStream.setBackgroundColor(
                                ContextCompat.getColor(this@DashboardActivity, R.color.primary)
                            )
                            binding.tvS23LiveIndicator.text = "S23: OFFLINE"
                            binding.tvS23LiveIndicator.setBackgroundResource(R.drawable.bg_indicator_red)
                            binding.tvOneplusLiveIndicator.text = "OP15: OFFLINE"
                            binding.tvOneplusLiveIndicator.setBackgroundResource(R.drawable.bg_indicator_red)
                            
                            binding.cardS23.visibility = View.VISIBLE
                            binding.cardOneplus.visibility = View.VISIBLE
                        }
                    }
                }

                // 2. Video Preview Render
                launch {
                    viewModel.s23PreviewBitmap.collectLatest { bitmap ->
                        if (bitmap != null) {
                            binding.ivS23Preview.setImageBitmap(bitmap)
                        } else {
                            binding.ivS23Preview.setImageResource(android.R.color.black)
                        }
                    }
                }

                launch {
                    viewModel.oneplusPreviewBitmap.collectLatest { bitmap ->
                        if (bitmap != null) {
                            binding.ivOneplusPreview.setImageBitmap(bitmap)
                        } else {
                            binding.ivOneplusPreview.setImageResource(android.R.color.black)
                        }
                    }
                }

                // 3. Last Uploaded Frame Thumbnail
                launch {
                    viewModel.lastUploadedBitmap.collectLatest { bitmap ->
                        if (bitmap != null) {
                            binding.ivLastSent.setImageBitmap(bitmap)
                        } else {
                            binding.ivLastSent.setImageResource(android.R.color.transparent)
                        }
                    }
                }

                // 4. Stream Frame Rates
                launch {
                    viewModel.s23Fps.collectLatest { fps ->
                        binding.tvS23Fps.text = "FPS: $fps"
                    }
                }

                launch {
                    viewModel.oneplusFps.collectLatest { fps ->
                        binding.tvOneplusFps.text = "FPS: $fps"
                    }
                }

                // 5. Processing Scores & Decisions
                launch {
                    viewModel.s23FrameScore.collectLatest { score ->
                        updateS23ScoreDisplay(score)
                    }
                }

                launch {
                    viewModel.oneplusFrameScore.collectLatest { score ->
                        updateOneplusScoreDisplay(score)
                    }
                }

                launch {
                    viewModel.s23IsFrameAccepted.collectLatest { accepted ->
                        updateRejectionReason()
                    }
                }

                launch {
                    viewModel.oneplusIsFrameAccepted.collectLatest { accepted ->
                        updateRejectionReason()
                    }
                }

                // 6. Network Dispatch & Statistics
                launch {
                    viewModel.repository.networkStatus.collectLatest { status ->
                        binding.tvNetStatus.text = "Status: $status"
                    }
                }

                launch {
                    viewModel.repository.uploadQueueSize.collectLatest { size ->
                        val latency = viewModel.repository.lastUploadTimeMs.value
                        binding.tvQueueStats.text = "Queue Length: $size  |  Upload Delay: ${latency}ms"
                    }
                }

                launch {
                    viewModel.s23LatencyVal.collectLatest { lat ->
                        updatePipelineStats()
                    }
                }

                launch {
                    viewModel.oneplusLatencyVal.collectLatest { lat ->
                        updatePipelineStats()
                    }
                }

                launch {
                    viewModel.s23RejectedCount.collectLatest { rej ->
                        updatePipelineStats()
                    }
                }

                launch {
                    viewModel.oneplusRejectedCount.collectLatest { rej ->
                        updatePipelineStats()
                    }
                }

                // 7. Snapdragon Diagnostics / Telemetry
                launch {
                    viewModel.diagnostics.collectLatest { diag ->
                        updateDiagnosticsDisplay(diag)
                    }
                }
            }
        }
    }

    private fun updateS23ScoreDisplay(score: FrameScore?) {
        if (score == null) {
            binding.tvS23Quality.text = "S23: --%"
            binding.tvS23Blur.text = "S23: --"
            binding.tvS23Motion.text = "S23: --%"
            binding.tvS23Reflection.text = "S23: --%"
            return
        }

        binding.tvS23Quality.text = "S23: ${score.quality}%"
        binding.tvS23Blur.text = "S23: ${score.blur.toInt()}"
        binding.tvS23Motion.text = "S23: ${String.format("%.1f", score.motion)}%"
        binding.tvS23Reflection.text = "S23: ${String.format("%.1f", score.reflection)}%"

        val qualityColor = when {
            score.quality >= 85 -> R.color.green_indicator
            score.quality >= 60 -> R.color.yellow_indicator
            else -> R.color.red_indicator
        }
        binding.tvS23Quality.setTextColor(ContextCompat.getColor(this, qualityColor))
    }

    private fun updateOneplusScoreDisplay(score: FrameScore?) {
        if (score == null) {
            binding.tvOneplusQuality.text = "OP15: --%"
            binding.tvOneplusBlur.text = "OP15: --"
            binding.tvOneplusMotion.text = "OP15: --%"
            binding.tvOneplusReflection.text = "OP15: --%"
            return
        }

        binding.tvOneplusQuality.text = "OP15: ${score.quality}%"
        binding.tvOneplusBlur.text = "OP15: ${score.blur.toInt()}"
        binding.tvOneplusMotion.text = "OP15: ${String.format("%.1f", score.motion)}%"
        binding.tvOneplusReflection.text = "OP15: ${String.format("%.1f", score.reflection)}%"

        val qualityColor = when {
            score.quality >= 85 -> R.color.green_indicator
            score.quality >= 60 -> R.color.yellow_indicator
            else -> R.color.red_indicator
        }
        binding.tvOneplusQuality.setTextColor(ContextCompat.getColor(this, qualityColor))
    }

    private fun updateRejectionReason() {
        val s23Reason = viewModel.s23RejectionReason.value
        val opReason = viewModel.oneplusRejectionReason.value
        
        val sb = StringBuilder()
        if (!viewModel.s23IsFrameAccepted.value && !s23Reason.isNullOrEmpty()) {
            sb.append("S23 Drop: $s23Reason\n")
        }
        if (!viewModel.oneplusIsFrameAccepted.value && !opReason.isNullOrEmpty()) {
            sb.append("OP15 Drop: $opReason")
        }
        
        binding.tvRejectionReason.text = sb.toString().trim()
        binding.tvRejectionReason.visibility = if (sb.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun updatePipelineStats() {
        val s23Lat = viewModel.s23LatencyVal.value
        val s23Rej = viewModel.s23RejectedCount.value
        binding.tvS23Latency.text = "S23 Pipeline: ${s23Lat}ms  |  Dropped: $s23Rej"

        val opLat = viewModel.oneplusLatencyVal.value
        val opRej = viewModel.oneplusRejectedCount.value
        binding.tvOneplusLatency.text = "OP15 Pipeline: ${opLat}ms  |  Dropped: $opRej"
    }

    private fun updateDiagnosticsDisplay(snapshot: DiagnosticsSnapshot?) {
        if (snapshot == null) {
            binding.tvThermalStatus.text = "Thermal Level: --"
            binding.tvTempDiag.text = "SoC Temp: --°C"
            binding.tvMemoryDiag.text = "JVM Heap: --MB  |  Native Heap: --MB"
            return
        }

        binding.tvThermalStatus.text = "Thermal Level: ${snapshot.thermalStatus}"
        binding.tvTempDiag.text = "SoC Temp: ${String.format("%.1f", snapshot.batteryTemp)}°C"
        binding.tvMemoryDiag.text = "JVM Heap: ${String.format("%.1f", snapshot.jvmHeapUsedMb)}MB  |  Native Heap: ${String.format("%.1f", snapshot.nativeHeapUsedMb)}MB"

        val thermalColor = when {
            snapshot.thermalStatus.contains("NONE") -> R.color.green_indicator
            snapshot.thermalStatus.contains("LIGHT") || snapshot.thermalStatus.contains("MODERATE") -> R.color.yellow_indicator
            else -> R.color.red_indicator
        }
        binding.tvThermalStatus.setTextColor(ContextCompat.getColor(this, thermalColor))
    }
}
