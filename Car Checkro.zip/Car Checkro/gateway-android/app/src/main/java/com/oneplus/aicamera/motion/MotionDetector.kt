package com.oneplus.aicamera.motion

import com.oneplus.aicamera.utils.MatPool
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc

/**
 * Detects motion between consecutive frames by calculating frame differences.
 */
class MotionDetector(private val matPool: MatPool) {

    /**
     * Compares the [current] frame with the [previous] frame.
     * Returns a motion score representing the percentage of pixels that changed (0.0 to 100.0).
     */
    fun calculateMotion(current: Mat, previous: Mat): Double {
        if (current.empty() || previous.empty()) return 0.0
        
        // Ensure same size
        if (current.rows() != previous.rows() || current.cols() != previous.cols()) {
            return 0.0
        }

        val currGray = matPool.obtain()
        val prevGray = matPool.obtain()
        val diffMat = matPool.obtain()
        val threshMat = matPool.obtain()

        try {
            // Convert current frame to gray
            if (current.channels() > 1) {
                Imgproc.cvtColor(current, currGray, Imgproc.COLOR_BGR2GRAY)
            } else {
                current.copyTo(currGray)
            }

            // Convert previous frame to gray
            if (previous.channels() > 1) {
                Imgproc.cvtColor(previous, prevGray, Imgproc.COLOR_BGR2GRAY)
            } else {
                previous.copyTo(prevGray)
            }

            // Absolute difference
            Core.absdiff(currGray, prevGray, diffMat)

            // Threshold the difference to highlight moving regions (binary mask)
            // Pixel diff value > 25 is considered motion
            Imgproc.threshold(diffMat, threshMat, 25.0, 255.0, Imgproc.THRESH_BINARY)

            // Count the number of white pixels
            val nonZeroCount = Core.countNonZero(threshMat)
            val totalPixels = threshMat.rows() * threshMat.cols()

            if (totalPixels == 0) return 0.0

            // Motion score = percentage of modified pixels
            return (nonZeroCount.toDouble() / totalPixels.toDouble()) * 100.0
        } catch (e: Exception) {
            return 0.0
        } finally {
            matPool.recycle(currGray)
            matPool.recycle(prevGray)
            matPool.recycle(diffMat)
            matPool.recycle(threshMat)
        }
    }

    /**
     * Checks if the motion score is below the configured threshold.
     */
    fun isStable(score: Double, threshold: Double): Boolean {
        return score <= threshold
    }
}
