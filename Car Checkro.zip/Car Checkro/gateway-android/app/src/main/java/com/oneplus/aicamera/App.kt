package com.oneplus.aicamera

import android.app.Application
import android.util.Log
import org.opencv.android.OpenCVLoader

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        initOpenCV()
    }

    private fun initOpenCV() {
        try {
            if (OpenCVLoader.initDebug()) {
                Log.i(TAG, "OpenCV initialized successfully.")
            } else {
                Log.e(TAG, "OpenCV initialization failed.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "OpenCV initialization failed with exception: ${e.message}", e)
        }
    }

    companion object {
        private const val TAG = "AICameraGatewayApp"
    }
}
