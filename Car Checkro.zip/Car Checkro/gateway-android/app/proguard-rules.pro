# Add project specific ProGuard rules here.
# By default, the noise/glare and OpenCV symbols should be kept if code shrinking is enabled.
-keep class org.opencv.** { *; }
-keep class com.quickbirdstudios.opencv.** { *; }
